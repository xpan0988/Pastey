# Mobile companion

Pastey has a development companion for iOS, iPadOS, and Android. The companion is a Bridge peer that requests work from a desktop Host. It uses the same pairing, encrypted Bridge traffic, workspace shares, and Agent lifecycle as the desktop app.

## Using the companion

1. Connect the phone or tablet and the desktop to the same private network. On the desktop, open Pastey and choose **New Bridge**.
2. In the companion, choose **Pair desktop**. Enter the desktop's private IPv4 address from its network settings and the eight-digit Bridge code displayed in Pastey. On iOS, allow Local Network access when prompted.
3. Open **Share** to exchange text. Open **Agents** to see workspaces that the desktop shares with this Bridge and start or continue Codex or Claude Code conversations where permitted. Session reading and Agent requests are separate switches in **Bridge details → Workspaces** on the desktop. The desktop's Accept or existing Full Access governs execution.
4. If the desktop gets a new address, update it in **Bridge settings**. If the Bridge requires a new pairing, generate a fresh code from that same Bridge on the desktop and select **Pair again** on mobile. **Burn Bridge** permanently removes its contents and access from the companion.

Keep the companion in the foreground while using it. The desktop must stay reachable and running Pastey. File transfer, local Agent execution, Developer Terminal, the Collaborations Journal, the internet carrier, push notifications, and offline delivery are outside this slice.

## Implementation

- The mobile Tauri entry point serves the phone and tablet layout at `mobile.html`. It registers only the IPC commands for Bridge management, text, and requesting desktop Agents. The desktop entry point keeps its own window lifecycle, tray, and shortcut.
- Pairing uses the desktop's address for unicast discovery and the existing SPAKE2 code handshake. Reconnect uses the saved address and pinned device keys. No multicast entitlement is needed on iOS. The address is a route, and the Bridge authenticates the peer. [Apple local network privacy](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)
- The companion registers zero local Agent adapters. Its room server accepts authenticated text and the existing control messages needed for membership and desktop task tracking. It rejects inbound work and omits file-transfer endpoints. Desktop Hosts continue to own session disclosure, execution review, and writer locks.
- The renderer refreshes rooms and text when it returns to the foreground and while it is visible. Agent views reuse the desktop task controller, including delivery uncertainty, reconciliation, and cancellation.

## Build and verify

Install the platform toolchain from [Tauri prerequisites](https://v2.tauri.app/start/prerequisites/). iOS device runs need full Xcode and an Apple development team. Android needs the SDK, NDK, and JDK. The generated Android project needs its standard `INTERNET` permission. Targeting Android API 37 or newer also requires a Local Network runtime permission flow, which is outside this implementation. [Android local network permission](https://developer.android.com/privacy-and-security/local-network-permission)

```sh
npm ci
npm run tauri -- ios init
npm run tauri -- ios dev
```

```sh
npm run tauri -- android init
npm run tauri -- android dev
```

Use `ios build` or `android build` in place of `dev` to build installed packages once the signing and SDK setup is ready. The local regression check uses the production room router and a deterministic Agent fixture on macOS:

```sh
npm run build
npm run test:frontend-integration
cargo test --manifest-path src-tauri/Cargo.toml --bin pastey mobile_companion_exchanges
```

Native mobile builds and devices have yet to be qualified. On each platform, verify first pairing with permission granted and denied, two-way text, shared-session reading, a desktop-approved Agent turn, disconnect and foreground reconnect, and Burn. Verify the software keyboard and safe areas on a phone and a tablet. For iOS, use a physical device for the Local Network permission check. [Apple local network privacy](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)
