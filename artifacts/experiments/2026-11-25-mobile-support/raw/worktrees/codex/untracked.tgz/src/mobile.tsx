import React from "react";
import ReactDOM from "react-dom/client";
import { MobileCompanion } from "./features/workspace/MobileCompanion";
import { applyAppearance } from "./lib/appearance";
import "./styles.css";
import "./mobile.css";

applyAppearance();

// WebKit can shrink the visual viewport for the keyboard while leaving the
// layout viewport the same height. Leave the user's zoom alone.
const viewport = window.visualViewport;
if (viewport) {
  const resize = () => {
    if (viewport.scale === 1) {
      document.documentElement.style.setProperty("--companion-height", `${viewport.height}px`);
      document.documentElement.style.setProperty("--companion-top", `${viewport.offsetTop}px`);
    }
  };
  viewport.addEventListener("resize", resize);
  viewport.addEventListener("scroll", resize);
  resize();
}

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode><MobileCompanion /></React.StrictMode>
);
