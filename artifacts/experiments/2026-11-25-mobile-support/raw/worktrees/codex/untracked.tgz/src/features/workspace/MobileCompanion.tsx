import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { reconcileRoomItems, reconcileRooms } from "../../lib/authoritativeSnapshots";
import { peerAddressProblem } from "../../lib/bridgeAddress";
import { sendTextToRoomWithBridgeRoute } from "../../lib/bridgeRoutingRuntime";
import { visibleBridgeRooms } from "../../lib/bridgeSelection";
import {
  burnRoom, getBridgePeerAddress, joinRoomAt, listRoomItems, listRooms,
  repairBridge, sendTextToRoom, setBridgePeerAddress,
} from "../../lib/tauri";
import type { RoomInfo } from "../../lib/types";
import { nativeAgentRecoveryRequiresAction, useNativeAgentTask } from "./AgentTaskLifecycle";
import { AgentWorkspace } from "./AgentWorkspace";
import { bridgeStatus } from "./BridgeNetworkPanel";
import { MessageCard, usePresentIdentityToPeers } from "./BridgeWorkspace";
import { ComposerInput, ConversationThread, SendButton, useSendGuard } from "./Conversation";
import { Dialog, Dot, EmptyState, Field, Icon, ListRow, Notice, Tabs, errorText } from "./ui";
import { roomMembers, roomPeers } from "./workspaceViewModel";

function useForegroundSnapshot<T>(
  read: () => Promise<T>,
  reconcile: (current: T, next: T) => T,
  initial: T,
) {
  const [value, setValue] = useState(initial);
  const [problem, setProblem] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const revision = useRef(0);

  useEffect(() => {
    let current = true;
    let fetching = false;
    async function refresh() {
      if (!current || fetching || document.hidden) return;
      const started = revision.current;
      fetching = true;
      try {
        const next = await read();
        if (current && started === revision.current) {
          setValue((previous) => reconcile(previous, next));
          setProblem(null);
        }
      } catch (error) {
        if (current && started === revision.current) setProblem(errorText(error, "Pastey could not refresh this view."));
      } finally {
        fetching = false;
        if (current) setReady(true);
      }
    }
    void refresh();
    const timer = window.setInterval(refresh, 2_000);
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("focus", refresh);
    return () => {
      current = false;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("focus", refresh);
    };
  }, [read, reconcile]);

  function update(change: (previous: T) => T) {
    revision.current += 1;
    setValue(change);
  }
  return { value, problem, ready, update };
}

function bridgeName(room: RoomInfo): string {
  return roomMembers(room)[0]?.displayName ?? room.peer_device_name ?? "Desktop";
}

export function MobileCompanion() {
  const rooms = useForegroundSnapshot(listRooms, reconcileRooms, []);
  const [selected, setSelected] = useState<string | null>(null);
  const [pairing, setPairing] = useState(false);
  const visible = visibleBridgeRooms(rooms.value);
  const room = visible.find((entry) => entry.id === selected);

  function paired(next: RoomInfo) {
    rooms.update((previous) => [...previous.filter((entry) => entry.id !== next.id), next]);
    setSelected(next.id);
    setPairing(false);
  }

  return <main className="mobile-shell">
    {rooms.problem ? <Notice tone="bad">{rooms.problem}</Notice> : null}
    {room ? <MobileBridge
      key={room.id}
      room={room}
      onBack={() => setSelected(null)}
      onPaired={paired}
      onBurned={() => {
        rooms.update((previous) => previous.filter((entry) => entry.id !== room.id));
        setSelected(null);
      }}
    /> : <section className="page mobile-room-list">
      <header className="page-header">
        <div className="page-header-main"><h1>Pastey</h1></div>
        <button type="button" className="btn btn-primary" onClick={() => setPairing(true)}><Icon name="plus" />Pair desktop</button>
      </header>
      <div className="page-body">
        <div className="content stack">
          {!rooms.ready ? <p role="status" className="muted">Loading Bridges…</p>
            : visible.length === 0 && !rooms.problem ? <EmptyState title="Connect to your desktop">
              Open Pastey on your desktop and create a new Bridge. Pair it here to share text and use its Agents.
            </EmptyState> : null}
          {visible.map((entry) => {
            const status = bridgeStatus(entry);
            return <ListRow
              key={entry.id}
              title={bridgeName(entry)}
              meta={<><Dot tone={status.tone} /> {status.label}</>}
              leading={<Icon name="device" />}
              side={<Icon name="chevron" />}
              onClick={() => setSelected(entry.id)}
            />;
          })}
        </div>
      </div>
    </section>}
    {pairing ? <ConnectionDialog onClose={() => setPairing(false)} onPaired={paired} /> : null}
  </main>;
}

function MobileBridge({ room, onBack, onPaired, onBurned }: {
  room: RoomInfo;
  onBack: () => void;
  onPaired: (next: RoomInfo) => void;
  onBurned: () => void;
}) {
  const [tab, setTab] = useState<"share" | "agents">("share");
  const [openedAgents, setOpenedAgents] = useState(false);
  const [dialog, setDialog] = useState<"connection" | "burn" | null>(null);
  const [problem, setProblem] = useState<string | null>(null);
  const [burning, setBurning] = useState(false);
  const peers = useMemo(() => roomPeers(room), [room]);
  const members = useMemo(() => roomMembers(room), [room]);
  const agent = useNativeAgentTask(room.id);
  const status = bridgeStatus(room);
  const name = bridgeName(room);
  usePresentIdentityToPeers(room.id, peers);
  const burn = useSendGuard(async () => {
    setBurning(true);
    setProblem(null);
    try {
      await burnRoom(room.id);
      onBurned();
    } catch (error) {
      setProblem(errorText(error, "Pastey could not burn this Bridge."));
    } finally {
      setBurning(false);
    }
  });

  return <section className="page">
    <header className="page-header">
      <button type="button" className="btn btn-ghost btn-icon" aria-label="Back to Bridges" onClick={onBack}><Icon name="back" /></button>
      <div className="page-header-main">
        <h1>{name}</h1>
        <p role="status"><Dot tone={status.tone} /> {status.label}</p>
      </div>
      <button type="button" className="btn btn-ghost btn-icon" aria-label="Bridge settings" onClick={() => setDialog("connection")}><Icon name="settings" /></button>
    </header>
    <div className="page-tabs">
      <Tabs<"share" | "agents">
        label="Bridge"
        value={tab}
        onChange={(next) => { setTab(next); if (next === "agents") setOpenedAgents(true); }}
        tabs={[
          { value: "share", label: "Share" },
          { value: "agents", label: "Agents", badge: nativeAgentRecoveryRequiresAction(agent.status, agent.movement) ? "!"
            : agent.status && ["queued", "running"].includes(agent.status.state) ? <Dot tone="live" pulse /> : undefined },
        ]}
      />
    </div>
    <div className="page" hidden={tab !== "share"}>
      <MobileShare room={room} name={name} connected={peers.length === 1} />
    </div>
    {openedAgents ? <div className="page" hidden={tab !== "agents"}>
      {members.some((member) => member.hostRef)
        ? <AgentWorkspace room={room} agent={agent} peers={peers} members={members} companion />
        : <EmptyState title="Desktop unavailable">Open Bridge settings to check its address or pair again.</EmptyState>}
    </div> : null}
    {dialog === "connection" ? <ConnectionDialog
      room={room}
      onClose={() => setDialog(null)}
      onPaired={(next) => { onPaired(next); setDialog(null); }}
      onBurn={() => { setProblem(null); setDialog("burn"); }}
    /> : null}
    {dialog === "burn" ? <Dialog
      title="Burn this Bridge?"
      description="This permanently removes this Bridge, its messages, and its access from this device."
      onClose={() => { if (!burning) setDialog(null); }}
      footer={<>
        <button type="button" className="btn" disabled={burning} onClick={() => setDialog(null)}>Cancel</button>
        <button type="button" className="btn btn-danger-solid" disabled={burning} onClick={burn}>{burning ? "Burning…" : "Burn Bridge"}</button>
      </>}
    >{problem ? <Notice tone="bad">{problem}</Notice> : null}</Dialog> : null}
  </section>;
}

function MobileShare({ room, name, connected }: { room: RoomInfo; name: string; connected: boolean }) {
  const read = useCallback(() => listRoomItems(room.id), [room.id]);
  const items = useForegroundSnapshot(read, reconcileRoomItems, []);
  const thread = useMemo(() => items.value.filter((item) => item.payload_type === "text").slice(-200), [items.value]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [problem, setProblem] = useState<string | null>(null);
  const send = useSendGuard(async () => {
    if (!connected || !text.trim()) return;
    setSending(true);
    setProblem(null);
    try {
      const sent = await sendTextToRoomWithBridgeRoute(room, text.trim(), sendTextToRoom);
      items.update((previous) => [...previous.filter((item) => item.id !== sent.id), sent]);
      if (sent.status === "sent") setText("");
      else setProblem(sent.error_message ?? "The desktop did not confirm delivery.");
    } catch (error) {
      setProblem(errorText(error, "Pastey could not send this text."));
    } finally {
      setSending(false);
    }
  });
  return <>
    <ConversationThread follow={thread}>
      {thread.map((item) => <MessageCard key={item.id} item={item} />)}
      {items.ready && !thread.length && !items.problem ? <EmptyState title={`Share with ${name}`}>Type or paste a message below.</EmptyState> : null}
    </ConversationThread>
    <div className="composer-wrap">
      {problem || items.problem ? <Notice tone="bad">{problem ?? items.problem}</Notice> : null}
      {!connected ? <p className="composer-hint" role="status">Text can be sent when the desktop reconnects.</p> : null}
      <section className="composer" aria-label="Share text">
        <ComposerInput value={text} onChange={setText} onSubmit={send} ariaLabel="Message" placeholder="Write a message…" pending={sending} />
        <div className="composer-bar"><span className="spacer" /><SendButton disabled={!connected || sending || !text.trim()} sending={sending} onClick={send} /></div>
      </section>
    </div>
  </>;
}

function ConnectionDialog({ room, onClose, onPaired, onBurn }: {
  room?: RoomInfo;
  onClose: () => void;
  onPaired: (room: RoomInfo) => void;
  onBurn?: () => void;
}) {
  const roomId = room?.id;
  const [saved, setSaved] = useState<string | null>(null);
  const [address, setAddress] = useState("");
  const [code, setCode] = useState("");
  const [repair, setRepair] = useState(room?.pairing_state === "pairing_required");
  const [loadingAddress, setLoadingAddress] = useState(Boolean(roomId));
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState<string | null>(null);
  const pairing = !roomId || repair;
  const compact = code.replace(/[\s-]/g, "");
  const title = !roomId ? "Pair a desktop" : repair ? "Pair this Bridge again" : "Bridge settings";

  useEffect(() => {
    if (!roomId) return;
    let current = true;
    void getBridgePeerAddress(roomId).then((existing) => {
      if (current) { setSaved(existing); setAddress(existing ?? ""); }
    }).catch((error) => {
      if (current) setProblem(errorText(error, "Pastey could not read the saved address."));
    }).finally(() => { if (current) setLoadingAddress(false); });
    return () => { current = false; };
  }, [roomId]);

  const submit = useSendGuard(async () => {
    if (loadingAddress) return;
    const invalid = peerAddressProblem(address);
    if (invalid) { setProblem(invalid); return; }
    if (pairing && !/^\d{8}$/.test(compact)) { setProblem("Enter the 8-digit Bridge code."); return; }
    setProblem(null);
    setBusy(true);
    try {
      if (!room) onPaired(await joinRoomAt(compact, address.trim()));
      else if (repair) onPaired(await repairBridge(room.id, compact, address.trim()));
      else {
        await setBridgePeerAddress(room.id, address.trim());
        onClose();
      }
    } catch (error) {
      const message = errorText(error, "Pastey could not connect to the desktop.");
      setProblem(/did not answer|timed out while waiting for room discovery/i.test(message)
        ? "The desktop did not answer. Check its address, the Bridge code, and that both devices are on the same network. On iOS, allow Pastey to access the local network."
        : message);
    } finally {
      setBusy(false);
    }
  });

  return <Dialog
    title={title}
    onClose={() => { if (!busy) onClose(); }}
    footer={<button type="submit" form="mobile-connection" className="btn btn-primary"
      disabled={busy || loadingAddress || (!pairing && address.trim() === saved)}>
      {busy ? (pairing ? "Pairing…" : "Saving…") : pairing ? "Pair Bridge" : "Save address"}
    </button>}
  >
    <form id="mobile-connection" className="stack" onSubmit={(event) => { event.preventDefault(); submit(); }}>
      {pairing ? <p>{repair ? "Open this Bridge on the desktop and generate a fresh pairing code." : "Open Pastey on your desktop and choose New Bridge. Enter its network address and the code it shows."}</p> : null}
      <Field label="Desktop address" htmlFor="mobile-address">
        <input id="mobile-address" className="input" value={address} onChange={(event) => setAddress(event.target.value)}
          placeholder="192.168.1.24" autoCapitalize="none" autoCorrect="off" spellCheck={false} disabled={loadingAddress || busy} />
      </Field>
      {pairing ? <Field label="Bridge code" htmlFor="mobile-code">
        <input id="mobile-code" className="input input-mono" value={code} onChange={(event) => setCode(event.target.value)}
          inputMode="numeric" autoComplete="off" placeholder="0000 0000" disabled={busy} />
      </Field> : null}
      {roomId ? <div className="row-wrap">
        {!pairing ? <button type="button" className="btn" disabled={busy} onClick={() => { setRepair(true); setProblem(null); }}>Pair again</button> : null}
        {onBurn ? <button type="button" className="btn btn-danger" disabled={busy} onClick={onBurn}>Burn Bridge…</button> : null}
      </div> : null}
      {problem ? <Notice tone="bad">{problem}</Notice> : null}
    </form>
  </Dialog>;
}
