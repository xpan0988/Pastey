#![cfg(mobile)]

include!("host_modules.rs");

mod mobile_companion;

#[tauri::mobile_entry_point]
pub fn run() {
    mobile_companion::run();
}
