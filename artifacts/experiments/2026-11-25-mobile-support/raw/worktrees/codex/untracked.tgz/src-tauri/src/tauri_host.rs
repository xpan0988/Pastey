use tauri::{AppHandle, Emitter};

use crate::{
    error::{AppError, AppResult},
    host_runtime::{HostEvent, HostEventSink, RuntimeTask, RuntimeTaskSpawner},
};

pub(crate) struct TauriHostEventSink {
    pub(crate) app_handle: AppHandle,
}

impl HostEventSink for TauriHostEventSink {
    fn emit(&self, event: HostEvent) -> AppResult<()> {
        self.app_handle
            .emit(event.name, event.payload)
            .map_err(|error| AppError::InvalidInput(format!("failed to emit Host event: {error}")))
    }
}

pub(crate) struct TauriRuntimeTaskSpawner;

impl RuntimeTaskSpawner for TauriRuntimeTaskSpawner {
    fn spawn(&self, task: RuntimeTask) {
        tauri::async_runtime::spawn(task);
    }
}
