use tauri::Manager;

use crate::{
    bridge_lifecycle, cleanup, commands,
    error::AppError,
    host_runtime::HostRuntime,
    logging,
    storage::AppPaths,
    tauri_host::{TauriHostEventSink, TauriRuntimeTaskSpawner},
};
use std::sync::Arc;

#[cfg_attr(not(mobile), allow(dead_code))]
pub(crate) fn run() {
    let app = tauri::Builder::default()
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            let data = app.path().app_data_dir().map_err(|error| {
                AppError::InvalidInput(format!(
                    "unable to resolve companion data directory: {error}"
                ))
            })?;
            let paths = AppPaths::new(data.clone(), data.join("logs"));
            paths.ensure_directories()?;
            let host = HostRuntime::initialize_companion(
                paths,
                Arc::new(TauriHostEventSink {
                    app_handle: app.handle().clone(),
                }),
                Arc::new(TauriRuntimeTaskSpawner),
            )?;
            app.manage(host.clone());
            logging::install_crash_reporting(env!("CARGO_PKG_VERSION"));
            host.spawn(bridge_lifecycle::start(host.clone()));
            cleanup::start_cleanup_scheduler(host);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::join_room_at,
            commands::repair_bridge,
            commands::list_rooms,
            commands::get_room,
            commands::get_bridge_peer_address,
            commands::set_bridge_peer_address,
            commands::burn_room,
            commands::list_room_items,
            commands::send_text_to_room,
            commands::copy_text_to_clipboard,
            commands::get_device_identity,
            commands::present_device_identity,
            commands::list_native_agent_capabilities,
            commands::list_remote_native_agent_capabilities,
            commands::list_remote_shared_workspaces,
            commands::discover_remote_native_sessions,
            commands::inspect_remote_native_session,
            commands::read_remote_native_model_catalogs,
            commands::start_remote_native_codex_task,
            commands::start_remote_native_claude_code_task,
            commands::continue_remote_native_session,
            commands::get_native_agent_recovery_projection,
            commands::get_native_agent_task_status,
            commands::reconcile_remote_native_agent_task,
            commands::cancel_remote_native_agent_task,
            commands::stop_bridge_native_agent_task,
            commands::respond_remote_native_decision,
        ])
        .build(tauri::generate_context!())
        .expect("error while building Pastey companion");
    app.run(|app, event| {
        if matches!(event, tauri::RunEvent::Exit) {
            if let Some(host) = app.try_state::<Arc<HostRuntime>>() {
                host.shutdown_all();
            }
            logging::record_clean_exit();
        }
    });
}
