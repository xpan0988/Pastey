# Mobile support: investigation and design (2026-11-25)

Status: design, with the first slice written on branch `exp/mobile-claude` and **not yet compiled or run**. The slice (below, [What is on this branch](#what-is-on-this-branch)) changes how the Rust crate is built and a small part of the UI. It was written in a session that could read and edit files but could not run `cargo`, `npm`, `xcodebuild` or a browser. Every claim about behaviour on a phone is therefore either read from the code or marked as not verified.

## What kind of evidence this is

- **Repository facts** come from the code at `3dec3dc` (`main`), named by file and function.
- **Platform facts** (iOS and Android rules, Tauri mobile, plugins) come from the author's knowledge of those platforms. No web search was available in this session, so none was checked against current documentation. Each is marked **to verify** where a wrong answer would change the design.
- Nothing here was measured on a phone.

## Goal

Make Pastey usable from a phone, in the way a phone is useful next to a Mac and a Windows PC: it is in the user's hand while the Agents work on the other devices.

**What a phone is in Pastey.** A phone is a **Bridge peer without Agent capabilities**, working while the app is open:
- it pairs with a desktop and shares text and files with it, both ways;
- it reaches **Agents on the other devices**: it starts and continues Codex and Claude Code conversations in folders those devices share, and reads the replies, under the same Review or Full Access those devices already apply to any requester;
- it shows what has been received (Inbox) and the state of each Bridge.

**What a phone is not.** It does not run Codex or Claude Code (neither has a mobile runtime), host a terminal, share folders, take part in workspace movement, or hold Agent collaborations. It does not receive pushed messages while the app is closed.

## Why this shape

| Option | What it is | Verdict |
|---|---|---|
| **A. Bridge peer, requester only** (this design) | The same Rust core as the desktop app, built for iOS and Android, with the Host-only parts left out | Chosen. One protocol, one authority model, and every feature that already works from one desktop to another works from a phone. |
| B. Remote UI in a phone browser | The desktop serves its screens; the phone's browser is the client | Rejected. A browser cannot do the pairing and encrypted Room Control (SPAKE2, X25519, ChaCha20-Poly1305, signed reconnect) without a second implementation of the protocol in JavaScript, and it would need its own answer to "who is this browser" (the Host-local authority rule in [architecture](../architecture.md#architecture-invariants)). |
| C. A phone as a full Host | A phone also offers capabilities | Not now. There is nothing to offer: no native Agent runs on a phone, and managed execution needs a confined process backend that does not exist there (`execution_backend.rs` already reports `Unsupported` on a platform it does not know). |

Option A needs no change to the Bridge, Room Control, Transfer or the native Agent lifecycle. A phone's capability observation lists no native Agents, so no peer is ever offered a phone to run work on.

## What the repository already gives, and what blocks

| Area | Fact | Consequence |
|---|---|---|
| Framework | Tauri 2 with React. `src-tauri/icons/android` and `icons/ios` already exist. There is no `gen/` project and no `iOS`/`android` bundle configuration. | `tauri android init` and `tauri ios init` are still to run (M1). |
| Crate shape | Before this branch the app was a binary crate: 59 modules declared in `main.rs`, no `lib.rs`. | Tauri mobile loads the app as a library (`#[tauri::mobile_entry_point]`). The crate had to become a library with a thin `main.rs`. Done on this branch. |
| Desktop-only code in startup | `install_tray`, `install_global_shortcut`, a hide-on-close window handler, and an argument check that exits with code 2 on any argument. | The argument check would kill the app on iOS: Xcode starts it with `-NSDocumentRevisionsDebugMode YES`. All four are `cfg(desktop)` now. |
| Cargo dependencies | `tauri-plugin-global-shortcut` is desktop only. `iroh` is built with `fast-apple-datapath`. | The plugin is now under a non-mobile target table. The feature is kept for macOS only: it uses Apple syscalls that are not public API (**to verify** in iroh's documentation before any App Store build). |
| Platform branches | Several hundred `cfg(target_os …)`/`cfg(unix)`/`cfg(windows)` sites (counted per file, tests included), mostly in `host_process.rs`, `safe_file_identity.rs`, `execution_backend.rs`, `device_profile.rs`, `native_agent/capability/*` and `developer_terminal.rs`. The code builds on Linux today, which makes Android and iOS look like "Linux-like Unix" to many of them. | **Not read site by site.** Whether the crate compiles for `aarch64-apple-ios` and `aarch64-linux-android` is unknown; a compiler finds the gaps in minutes (M1). Expect gates of the form `cfg(target_os = "linux")` with no fallback, and `portable-pty` (Developer Terminal host side). |
| Process spawning | Codex and Claude Code adapters spawn child processes; `discovery_interfaces()` shells out to `ip` and `ifconfig`. | A phone cannot spawn them. The interface list comes back empty there and discovery falls back to the limited broadcast `255.255.255.255` only. The Agent adapters must not register on a phone (M1). |
| Discovery | UDP on port 48392: a LAN broadcast to find a code, a unicast query to a remembered address (`DiscoveryTargets::Unicast`, used by `join_room_at`). Addresses must be private or overlay IPv4. | Pairing and reconnect by **address** work with unicast. Pairing by **code alone** needs broadcast (below). |
| Sessions | LAN liveness: probe every 2 s, 1.8 s timeout, session ends after 3 failures (`bridge_lifecycle.rs`). Both sides run a reconcile loop that reconnects a pinned Bridge. | A phone that is suspended stops answering, and the desktop ends the session within about ten seconds (three failed probes, 2 s apart). Reconnect when the phone returns is automatic if the loop and sockets are alive (below). |
| Files | `send_file_to_room` takes a path and reads it with `std::fs`. The file dialog returns paths. `write_temp_file` takes `Vec<u8>` as a JSON number array. | A phone's picker gives no readable path (below), and a JSON array of numbers is far too heavy for a photo. |
| UI | One stylesheet with breakpoints at 1080, 860 and 680 px, a sidebar that becomes an overlay below 680 px, a touch-first default for the Return key, 13.5 px text and 32 px controls. | The layout already collapses. It lacks safe-area insets, `dvh`, 44 px targets and 16 px inputs (iOS zooms the page on a smaller field). |
| Documents | [Layer 4 connectivity](../layers/layer-4-connectivity.md#limitations) and [Layer 1](../layers/layer-1-transfer.md) say mobile devices are out of scope. | Update both when M2 passes. |

## Design

### Lifecycle: foreground only

A phone's system suspends the app soon after it leaves the screen. While it is suspended it answers no probe, accepts no request and sends nothing. The design accepts that and does not try to avoid it (push wake-up and offline delivery stay out of scope, as in [Layer 4](../layers/layer-4-connectivity.md#limitations)):

- A desktop shows the phone as disconnected while its app is closed. An in-flight transfer fails as any interrupted transfer does, and sending the same file again resumes it ([Layer 1](../layers/layer-1-transfer.md)).
- A task the phone started on a desktop keeps running there. When the phone returns it reads the state again through the existing reconcile paths. Nothing is rerun.
- On return to the foreground the phone must have working sockets: the room server's listener, the discovery service and the reconcile loop. A suspended app's sockets can be closed by the system (**to verify** on a device). M2 adds a resume hook that restarts them (`transfer::start_room_server`, `discovery::ensure_service`) and asks the reconcile loop to run at once. The frontend can raise it from `visibilitychange`; the Rust side does not depend on a Tauri lifecycle event whose name this session could not check.

### Pairing

A phone is always the **joiner** in the first release. The desktop creates the Bridge and shows an 8-digit code, and now also **its own private address** (`get_local_network_addresses`, shown under the code in Bridge details). The phone's New Bridge screen defaults to "Pair by the other device's address" and calls the existing `join_room_at(code, address)`. The code stays the SPAKE2 password and the address only says where to look, exactly as for an overlay address today ([Layer 4](../layers/layer-4-connectivity.md#overlay-address)).

Why not broadcast. On iOS, sending or receiving UDP broadcast or multicast needs Apple's multicast entitlement, which Apple grants on request (**to verify**); unicast to the local network needs only the Local Network permission prompt. Android needs a multicast lock and a permission for broadcast and works without Apple-style approval. Planning around the stricter platform keeps one flow for both: unicast to a typed (later scanned) address.

Consequences:
- The phone does not create a Bridge for a desktop to join by code in the first release, and its "Nearby" list may show nothing. A desktop's Nearby list may not see a phone either (its beacon is a broadcast).
- Reconnect uses the address the phone remembers for the desktop (`set_bridge_peer_address`, filled in by `join_room_at`). If the desktop's address changes (DHCP), reconnect fails until it is entered again, or until the internet carrier (iroh) is on at both ends, which pins keys, not addresses. A Bonjour (iOS) and NSD (Android) discovery would remove this (M4).
- **QR pairing** (the desktop shows a QR of `code + address`, the phone scans it) removes the typing. It needs a QR encoder and a camera scanner, which means a new dependency on each side (a Rust or npm QR crate on the desktop, `tauri-plugin-barcode-scanner` on the phone, and the camera permission text in `Info.plist`/the manifest). Not written: this session could not install packages. M4.

### Sending and receiving files

- **Phone to desktop.** The picker gives the page a `File`, not a path (Android returns a `content://` address that `std::fs` cannot open; iOS hands a copy that only the picker's process owns — **to verify**). The page reads the bytes and calls the new `write_temp_file_raw` command, which takes the bytes as the request's raw body and the name in a header, and stores them under the temp folder. The file is queued like any other, with `deleteWhenDone`, so the copy is removed after the send. The existing `write_temp_file` stays for its current uses: it takes a JSON array of numbers, which for a 10 MB photo is about 40 MB of JSON.
  - The first release limits this path to **64 MB** per file, because the page and Pastey both hold the whole file. The limit is a constant (`PHONE_FILE_LIMIT_BYTES`) and the user is told which files were left out. A chunked hand-over that streams from `File.stream()` into an append command lifts it (M2).
- **Desktop to phone.** The existing receive path writes into the app's Inbox folder under its data directory. That folder is private to the app on both systems. M3 decides how the user gets a received file out: the system share sheet or "Save to Files" (iOS), a save into Downloads through the media store (Android). Until then "Show in folder" on a phone returns a plain error (`reveal_in_folder` and `open_logs_folder` have `cfg(mobile)` stubs).
- Drag and drop does not exist on a phone and is not offered.

### Agents from a phone

Everything below already exists for a desktop that is not the one running the Agent; the phone is another requester.

- The Agents tab lists the other device's shared workspaces and their sessions, starts a conversation (Codex or Claude Code) and continues a session, and shows the reply.
- Authority is unchanged: the executing device's Accept for each run, or the Full Access its user gave to this phone. Nothing in a phone's state can raise either.
- Hidden on a phone: "This device" workspaces and Add a folder, New conversation on a local workspace, sharing a workspace, workspace movement, Developer Mode, Collaborations (a collaboration groups this device's own native sessions, and a phone has none), the global shortcut setting.
- **Full Access to a phone needs its own warning.** A phone is lost more easily than a desktop, and Full Access lets its holder run Agents on the desktop unattended. Today's consent dialog names the device and what it allows. It should also say when the device is a phone (the platform name now reads `iOS` or `Android`, from `discovery::platform_name`) and that an unlocked phone then controls this device. M3.
- **Approving from the phone is out of scope.** The Accept or Deny of an executor Review is the executing Host's local user's decision ([architecture invariants](../architecture.md#architecture-invariants)). Letting a phone answer it would be a new authority path (a "remote approver" grant) and needs its own design.

### Crate structure

```text
src-tauri/src/lib.rs    all modules + pub fn run()   #[cfg_attr(mobile, tauri::mobile_entry_point)]
src-tauri/src/main.rs   fn main() { pastey_lib::run() }
Cargo.toml              [lib] name = "pastey_lib", crate-type = ["staticlib", "cdylib", "rlib"]
```

- The library is named `pastey_lib`, not `pastey`, so its output does not collide with the executable's (this is Tauri's own template).
- `cfg(desktop)` and `cfg(mobile)` come from `tauri-build`; they are not Cargo features. Desktop behaviour is behind `cfg(desktop)` so a desktop build compiles exactly what it did.
- Capabilities (`src-tauri/capabilities`): `default.json` is limited to macOS, Windows and Linux; `mobile.json` grants a phone only the app, event, path, webview and dialog permissions.
- **Test commands change.** Unit tests now live in the library, so `cargo test … --bin pastey <filter>` finds nothing. Use `--lib`. `docs/development.md`, the Windows stage-5 script, `tools/ui-bridge/README.md` and two doc comments were updated. `cargo check … --bin pastey` still checks the library, because the binary depends on it. `cargo test --all-targets` (the CI command) is unaffected.
- Tests that start `target/debug/pastey` as a helper (the Claude Code lifeline) still find it, because `cargo build` still builds the binary.

### Security and privacy

- A phone is a Bridge peer like any other: SPAKE2 pairing, a pinned device key, signed reconnect, encrypted Room Control. No new route, no new authority.
- The room server of a phone listens on all interfaces while the app is open, as a desktop's does. The same rule holds: the code and keys decide, never the address. Local Network permission on iOS and the network state on Android are the user's to grant; Pastey does not ask for more.
- The Bridge's secrets are in the app's data directory, wrapped by an installation master key stored in the same configuration (`config::master_key`). On a phone the app sandbox protects them from other apps, not from someone holding an unlocked phone. Moving the master key into the Keychain or Keystore, and an optional biometric lock when the app opens, are M4. Until then the answer to a lost phone is the existing one: **Forget** or **Burn** on the desktop revokes it at once.
- Cleartext: Pastey's Bridge traffic is its own encrypted protocol over raw sockets, which the system's HTTP-cleartext rules (App Transport Security, Android's network security configuration) do not govern. They govern only the WebView's own page loads, and the app loads none from the network (**to verify** when the shell exists).

## Milestones and acceptance tests

M0 is this branch. Each later milestone needs hardware or a simulator and is **not started**.

| | Scope | Acceptance |
|---|---|---|
| **M0** | Library crate, `cfg(desktop)` gating, mobile capability, address display, raw temp-file command, platform helper, responsive and safe-area CSS, hidden desktop-only controls, this document. | On a desktop: `cargo fmt --check`, `cargo check --bin pastey`, `cargo test --all-targets`, `npm run build`, `npm run test:frontend-integration` pass, and the app behaves as before. **None of these has been run.** |
| **M1** | The crate compiles for `aarch64-apple-ios`, `aarch64-apple-ios-sim` and `aarch64-linux-android`. Agent adapters and Developer Terminal host side are not registered on a phone. `tauri ios init` and `tauri android init`, with `src-tauri/gen` committed. The app starts in the simulator and the emulator: Host initialized, device identity created, room servers bound, UI shown. | Three `cargo check` targets clean. Two screenshots (iOS simulator, Android emulator) of the New Bridge screen. `list_native_agent_capabilities` reports none on a phone. |
| **M2** | Pair and Share on real devices: join by address and code; text and files both ways; resume hook; reconnect after the app returns. | An iPhone and a Mac on one Wi-Fi: join by address in under 10 s; text both ways; a 20 MB file each way with matching digests; background the app for 30 s, foreground it, and the Bridge shows connected within 15 s (3 of 3 runs). The same on an Android phone. A file over 64 MB is refused with the message, not sent. |
| **M3** | Agents from a phone, hidden Host-only screens, the Full Access phone warning, getting a received file out of the app, Inbox. | From the phone: start a Claude Code conversation in a folder the Mac shares, after the Mac's Accept; read the reply; continue it. With Full Access given, the same without the Mac's Accept. The consent dialog names the phone. |
| **M4** | QR pairing; Bonjour and NSD discovery for reconnect; Keychain/Keystore for the master key and a biometric lock; chunked file hand-over; notifications are still out. | Pair by QR in under 10 s. Change the desktop's address mid-session and the phone reconnects with no typing. A file over 64 MB sends. |

## What is on this branch

All of this is source only: nothing was built, run or tested.

**Rust**
- `src-tauri/src/lib.rs` is the old `main.rs` with `pub fn run()` and `#[cfg_attr(mobile, tauri::mobile_entry_point)]`; the tray, global shortcut, close handler, argument check and Claude Code lifeline are `cfg(desktop)`; `main.rs` calls `pastey_lib::run()`.
- `Cargo.toml`: `[lib]`; the global-shortcut plugin and iroh's `fast-apple-datapath` moved to target tables.
- `capabilities/default.json` (desktop only) and `capabilities/mobile.json`.
- `commands.rs`: `write_temp_file_raw`, `get_local_network_addresses`, and `cfg(mobile)` stubs for `reveal_in_folder` and `open_logs_folder`.
- `discovery.rs`: `local_private_ipv4_addresses` (with a test) and `iOS`/`Android` in `platform_name`.

**Frontend**
- `index.html`: `viewport-fit=cover`.
- `styles.css`: safe-area padding, `100dvh`, 44 px controls and 16 px inputs for a coarse pointer.
- `lib/platform.ts` (`devicePlatform`, `isMobilePlatform`; `?platform=ios` previews it in a desktop browser), `lib/mobileFiles.ts`, `writeTempFileRaw` and `getLocalNetworkAddresses` in `lib/tauri.ts`.
- Send files on a phone, the New Bridge screen's address flow and the address line under an open code, no Collaborations item, no global-shortcut row.
- Two tests in `tests/frontendIntegration.test.ts`.

**Documentation:** test commands changed from `--bin pastey` to `--lib` where they ran tests.

## Things to check first when a compiler is available

1. `cargo check --manifest-path src-tauri/Cargo.toml --bin pastey` on the Mac. The likeliest faults, in order: `cfg(desktop)` not being defined (it should come from `tauri-build`; if it is not, `build.rs` needs `cfg_aliases`), the `tauri::ipc::Request` signature of `write_temp_file_raw`, and a dead-code warning for something that was only used by a now-gated block.
2. `cargo test --manifest-path src-tauri/Cargo.toml --lib` against a run on `main`: the same tests, the same count. The tests that start `std::env::current_exe()` as a helper process (`claude_code/tests.rs`, `job/tests.rs`, `conversation/tests.rs`) run the same harness again by test name, so they should not notice the split; confirm that.
3. `npm run build` and `npm run test:frontend-integration`.
4. Then M1's three mobile targets.

## Open product decisions

1. **Which phone first.** Default: iOS first (the project's measurements use an iPhone hotspot, so the owner has one), Android straight after, since almost all of M1 to M3 is shared. A free Apple developer account is enough to run on one's own iPhone for M1 to M3 (**to verify**: such installs expire after about a week); the paid programme is needed only for TestFlight and the multicast entitlement.
2. **Test commands and build time.** The library split changes `--bin pastey` to `--lib` in every documented test command. It also makes a desktop release build link the library three times (`staticlib`, `cdylib`, `rlib`), which Tauri's own template does too but which costs link time with `lto = true`; measure it on the first compile. There is no way to keep the binary crate and still load the app on a phone, so the real choice is only whether to accept these two costs. If the link time matters, the crate types could be narrowed on desktop; how the Tauri CLI would then build the phone library was not investigated.
3. **Full Access to a phone.** Allow it with the warning above (default), or refuse it by platform.
4. **Receiving files on a phone.** Share sheet and "Save to Files"/Downloads (default), or a visible folder in the app's own Documents.
