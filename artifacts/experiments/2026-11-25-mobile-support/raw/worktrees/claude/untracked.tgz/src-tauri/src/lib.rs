mod bridge_auth;
mod bridge_lifecycle;
mod bridge_plan;
mod bridge_plan_v2;
mod capability_acquisition_confirmation;
mod capability_probe;
mod chunk_frame;
mod cleanup;
mod collaboration;
mod commands;
mod config;
mod connectivity;
mod crypto;
mod dev_tools;
mod developer_terminal;
mod device_identity;
mod device_profile;
mod device_trust;
mod diagnostics;
mod discovery;
mod effect_authority;
mod error;
mod execution_backend;
mod execution_world;
mod file_candidates;
mod full_access;
mod host_admission;
mod host_identity;
mod host_process;
mod host_runtime;
mod link_benchmark;
mod logging;
mod managed_execution;
mod managed_objects;
mod managed_resources;
mod managed_runtime_config;
mod managed_worker_coordinator;
mod managed_workspace;
mod models;
mod native_agent;
mod native_v2_orchestration;
mod natural_v2;
mod network_broker;
mod object_refs;
mod peer_capabilities;
mod regular_file_set_transfer;
mod room_control;
mod safe_file_identity;
mod session_read_access;
mod storage;
mod transfer;
mod transfer_orchestration;
mod transfer_tuning;
#[cfg(windows)]
mod windows_codex_backend;
#[cfg(any(windows, test))]
mod windows_verifier_diagnostics;
mod worker_harness;
mod worker_provider;
mod worker_provider_config;

use std::{path::PathBuf, sync::Arc};

use tauri::{AppHandle, Emitter, Manager};
// The tray, the global shortcut and the hide-on-close window are desktop
// behaviour. A phone has no tray or global shortcut, and its window is the
// whole app (docs/research/mobile-support.md).
#[cfg(desktop)]
use tauri::{
    menu::MenuBuilder,
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    WindowEvent,
};
#[cfg(desktop)]
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut, ShortcutState};

use crate::{
    commands::{
        accept_developer_terminal, accept_native_invocation_review, accept_nearby_join,
        approve_bridge_plan, approve_native_v2_plan,
        approve_remote_native_codex_workspace_movement, authorize_search_folder,
        bind_bridge_plan_to_session, burn_room, cancel_native_agent_task,
        cancel_native_v2_plan_attempt, cancel_remote_native_agent_task, cancel_transfer,
        check_for_updates, check_managed_worker_provider_health, close_developer_terminal,
        close_hosted_developer_terminal, complete_nearby_join, compose_native_v2_plan,
        compose_natural_v2_candidate, confirm_capability_acquisition, continue_native_session,
        continue_remote_native_session, copy_last_error, copy_text_to_clipboard,
        create_composed_file_bridge_plan, create_direct_file_transfer_bridge_plan,
        create_managed_worker_provider, create_room, delete_managed_worker_provider,
        delete_temp_file, deny_developer_terminal, deny_native_invocation_review,
        discard_native_agent_conflict_result, discover_native_sessions,
        discover_remote_native_sessions, enter_developer_mode, forget_known_device,
        get_bridge_full_access, get_bridge_internet_status, get_bridge_node_list_projection,
        get_bridge_peer_address, get_config, get_developer_terminal_workspace,
        get_local_network_addresses,
        get_device_capabilities, get_device_identity, get_device_profile,
        get_file_transfer_metadata, get_internet_connectivity, get_last_benchmark_results,
        get_managed_worker_provider_settings, get_native_agent_recovery_projection,
        get_native_agent_task_session, get_native_agent_task_status,
        get_native_agent_workspace_movement_status, get_native_v2_plan_status, get_room,
        get_room_control_diagnostics, get_room_control_session_context, grant_full_access,
        inspect_native_session, inspect_remote_native_session, join_room, join_room_at,
        list_authorized_search_folders, list_bridge_plan_workspace, list_bridge_workspace_shares,
        list_full_access, list_known_devices, list_managed_runtime_options,
        list_native_agent_capabilities, list_native_invocation_reviews, list_nearby_devices,
        list_received_room_control_events, list_remote_native_agent_capabilities,
        list_remote_shared_workspaces, list_room_items, list_rooms, list_seen_peer_devices,
        list_session_read_grants, list_trusted_devices, log_frontend_diagnostic,
        mark_bridge_peer_pairing_rotation_required, mark_join_prompt_rendered, open_bridge_pairing,
        open_logs_folder, open_remote_folder, pair_bridge_peer, pending_join_requests,
        present_device_identity, propose_remote_native_codex_workspace_movement,
        read_native_agent_defaults, read_native_model_catalogs, read_remote_native_model_catalogs,
        reconcile_remote_native_agent_task, refresh_selected_peer_capabilities, reject_nearby_join,
        remove_full_access_folder, repair_bridge, request_developer_terminal, request_nearby_join,
        resize_developer_terminal, respond_remote_native_decision,
        retry_native_agent_workspace_result_return, reveal_in_folder,
        reveal_native_agent_conflict_result, revoke_authorized_search_folder,
        revoke_bridge_peer_pairing, revoke_full_access, revoke_trusted_device,
        rotate_device_identity, run_bridge_device_diagnostics, run_bridge_device_self_check,
        run_loopback_benchmark, run_peer_link_benchmark, select_bridge_plan_search_candidate,
        select_managed_execute_runtime, select_managed_worker_provider,
        send_developer_terminal_input, send_file_to_room, send_text_to_room,
        set_bridge_peer_address, set_internet_connectivity, share_bridge_workspace,
        start_bridge_plan_attempt, start_native_claude_code_task, start_native_codex_task,
        list_collaborations, get_collaboration, create_collaboration, set_collaboration_state,
        delete_collaboration, send_collaboration_message, approve_collaboration_messages,
        dismiss_collaboration_entry, resume_collaboration_member, collaboration_needs_you_count,
        set_collaboration_grant, withdraw_collaboration_grant, add_collaboration_member,
        remove_collaboration_member, set_collaboration_goal, set_collaboration_role,
        decide_collaboration_summary, invite_collaboration_member, list_collaboration_invitations,
        answer_collaboration_invitation,
        start_native_v2_plan_attempt, start_remote_native_capability_task,
        start_remote_native_claude_code_task, start_remote_native_codex_task,
        stop_bridge_native_agent_task, stop_sharing_workspace, trust_peer_device, update_config,
        update_managed_worker_provider, update_transfer_window, update_workspace_share,
        withdraw_bridge_plan_revision, write_temp_file, write_temp_file_raw,
    },
    error::{AppError, AppResult},
    host_runtime::{HostEvent, HostEventSink, HostRuntime, RuntimeTask, RuntimeTaskSpawner},
    storage::AppPaths,
};

const APP_DATA_DIR_ENV: &str = "PASTEY_APP_DATA_DIR";

struct TauriHostEventSink {
    app_handle: AppHandle,
}

impl HostEventSink for TauriHostEventSink {
    fn emit(&self, event: HostEvent) -> AppResult<()> {
        self.app_handle
            .emit(event.name, event.payload)
            .map_err(|error| AppError::InvalidInput(format!("failed to emit Host event: {error}")))
    }
}

struct TauriRuntimeTaskSpawner;

impl RuntimeTaskSpawner for TauriRuntimeTaskSpawner {
    fn spawn(&self, task: RuntimeTask) {
        tauri::async_runtime::spawn(task);
    }
}

/// The app's entry point: `main` on a desktop, and on a phone the function
/// Tauri's generated Android/iOS shell calls. It lives in this library, not
/// in `main.rs`, because a phone loads the app as a library.
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    #[cfg(windows)]
    if windows_codex_backend::run_helper_if_requested() {
        return;
    }
    // A Claude Code run's lifeline: Pastey's own executable, started again.
    // A phone runs no Claude Code, so it has no lifeline.
    #[cfg(all(unix, desktop))]
    if native_agent::run_claude_code_lifeline_if_requested() {
        return;
    }
    // The desktop app takes no arguments. Anything else is a launcher Pastey
    // no longer answers (such as a stale MCP entry), so refuse it instead of
    // opening a second Host on this device's data. Not on a phone: the system
    // and its tools (Xcode passes `-NSDocumentRevisionsDebugMode YES`) start
    // the app with arguments of their own.
    #[cfg(desktop)]
    if let LaunchMode::Refused(argument) = launch_mode(std::env::args_os().skip(1)) {
        eprintln!(
            "pastey: unsupported argument {argument:?}. The Pastey app starts only without \
             arguments; if an MCP client or launcher starts Pastey with this argument, \
             remove that entry."
        );
        std::process::exit(2);
    }
    let builder = tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            let shortcut_label = default_shortcut_label();
            let paths = desktop_app_paths(app.handle())?;
            let state = HostRuntime::initialize(
                paths,
                shortcut_label,
                Arc::new(TauriHostEventSink {
                    app_handle: app.handle().clone(),
                }),
                Arc::new(TauriRuntimeTaskSpawner),
            )?;

            app.manage(state.clone());
            logging::install_crash_reporting(env!("CARGO_PKG_VERSION"));
            // Agent collaborations: deliver at turn boundaries from now on.
            collaboration::start_scheduler(&state);
            let antenna_state = state.clone();
            state.spawn(async move {
                if discovery::ensure_service(antenna_state.clone())
                    .await
                    .is_err()
                {
                    logging::write_error_line(
                        "[pastey antenna] event=antenna_start error_code=service_unavailable",
                    );
                    return;
                }
                discovery::start_antenna(antenna_state).await;
            });
            let lifecycle_state = state.clone();
            state.spawn(async move {
                bridge_lifecycle::start(lifecycle_state).await;
            });
            // Internet connectivity, only if this device's user turned it on.
            let connectivity_state = state.clone();
            state.spawn(async move {
                connectivity::start(connectivity_state).await;
            });
            #[cfg(desktop)]
            {
                install_global_shortcut(app.handle())?;
                install_tray(app.handle())?;
            }
            cleanup::start_cleanup_scheduler(state);
            Ok(())
        });
    // Closing the window hides it and keeps the Host running behind the tray.
    // A phone has no window to close: the system suspends or ends the app.
    #[cfg(desktop)]
    let builder = builder.on_window_event(|window, event| {
        if let WindowEvent::CloseRequested { api, .. } = event {
            api.prevent_close();
            let app = window.app_handle().clone();
            if let Some(state) = app.try_state::<Arc<HostRuntime>>() {
                let state = state.inner().clone();
                let task_state = state.clone();
                state.spawn(async move {
                    discovery::stop_antenna(task_state).await;
                });
            }
            let _ = window.hide();
        }
    });
    let app = builder
        .invoke_handler(tauri::generate_handler![
            create_room,
            open_bridge_pairing,
            repair_bridge,
            list_known_devices,
            forget_known_device,
            join_room,
            join_room_at,
            get_device_identity,
            rotate_device_identity,
            present_device_identity,
            list_seen_peer_devices,
            trust_peer_device,
            list_trusted_devices,
            revoke_trusted_device,
            get_bridge_full_access,
            list_full_access,
            grant_full_access,
            revoke_full_access,
            remove_full_access_folder,
            get_bridge_peer_address,
            get_local_network_addresses,
            set_bridge_peer_address,
            list_nearby_devices,
            request_nearby_join,
            complete_nearby_join,
            accept_nearby_join,
            reject_nearby_join,
            pending_join_requests,
            mark_join_prompt_rendered,
            list_rooms,
            get_room,
            pair_bridge_peer,
            revoke_bridge_peer_pairing,
            mark_bridge_peer_pairing_rotation_required,
            list_room_items,
            send_text_to_room,
            send_file_to_room,
            create_composed_file_bridge_plan,
            create_direct_file_transfer_bridge_plan,
            refresh_selected_peer_capabilities,
            compose_natural_v2_candidate,
            compose_native_v2_plan,
            approve_native_v2_plan,
            start_native_v2_plan_attempt,
            get_native_v2_plan_status,
            cancel_native_v2_plan_attempt,
            list_native_agent_capabilities,
            discover_native_sessions,
            read_native_agent_defaults,
            read_native_model_catalogs,
            read_remote_native_model_catalogs,
            inspect_native_session,
            continue_native_session,
            get_internet_connectivity,
            set_internet_connectivity,
            get_bridge_internet_status,
            continue_remote_native_session,
            discover_remote_native_sessions,
            inspect_remote_native_session,
            list_session_read_grants,
            list_bridge_workspace_shares,
            share_bridge_workspace,
            update_workspace_share,
            stop_sharing_workspace,
            list_remote_shared_workspaces,
            open_remote_folder,
            list_authorized_search_folders,
            authorize_search_folder,
            revoke_authorized_search_folder,
            list_remote_native_agent_capabilities,
            start_native_codex_task,
            start_native_claude_code_task,
            list_collaborations,
            get_collaboration,
            create_collaboration,
            set_collaboration_state,
            delete_collaboration,
            send_collaboration_message,
            approve_collaboration_messages,
            dismiss_collaboration_entry,
            resume_collaboration_member,
            collaboration_needs_you_count,
            set_collaboration_grant,
            withdraw_collaboration_grant,
            add_collaboration_member,
            remove_collaboration_member,
            set_collaboration_goal,
            set_collaboration_role,
            decide_collaboration_summary,
            invite_collaboration_member,
            list_collaboration_invitations,
            answer_collaboration_invitation,
            get_native_agent_task_session,
            get_native_agent_task_status,
            cancel_native_agent_task,
            list_native_invocation_reviews,
            accept_native_invocation_review,
            deny_native_invocation_review,
            start_remote_native_codex_task,
            start_remote_native_capability_task,
            start_remote_native_claude_code_task,
            cancel_remote_native_agent_task,
            respond_remote_native_decision,
            stop_bridge_native_agent_task,
            propose_remote_native_codex_workspace_movement,
            approve_remote_native_codex_workspace_movement,
            get_native_agent_workspace_movement_status,
            get_native_agent_recovery_projection,
            reveal_native_agent_conflict_result,
            discard_native_agent_conflict_result,
            retry_native_agent_workspace_result_return,
            reconcile_remote_native_agent_task,
            list_bridge_plan_workspace,
            approve_bridge_plan,
            withdraw_bridge_plan_revision,
            bind_bridge_plan_to_session,
            start_bridge_plan_attempt,
            select_bridge_plan_search_candidate,
            get_room_control_session_context,
            list_received_room_control_events,
            get_room_control_diagnostics,
            enter_developer_mode,
            get_developer_terminal_workspace,
            request_developer_terminal,
            accept_developer_terminal,
            close_hosted_developer_terminal,
            deny_developer_terminal,
            send_developer_terminal_input,
            resize_developer_terminal,
            close_developer_terminal,
            cancel_transfer,
            update_transfer_window,
            write_temp_file,
            write_temp_file_raw,
            get_file_transfer_metadata,
            delete_temp_file,
            burn_room,
            get_config,
            list_managed_runtime_options,
            select_managed_execute_runtime,
            get_managed_worker_provider_settings,
            create_managed_worker_provider,
            update_managed_worker_provider,
            delete_managed_worker_provider,
            select_managed_worker_provider,
            check_managed_worker_provider_health,
            get_device_profile,
            get_device_capabilities,
            confirm_capability_acquisition,
            get_bridge_node_list_projection,
            run_bridge_device_diagnostics,
            run_bridge_device_self_check,
            run_loopback_benchmark,
            run_peer_link_benchmark,
            get_last_benchmark_results,
            update_config,
            reveal_in_folder,
            open_logs_folder,
            copy_last_error,
            check_for_updates,
            copy_text_to_clipboard,
            log_frontend_diagnostic
        ])
        .build(tauri::generate_context!())
        .expect("error while building pastey");
    app.run(|app_handle, event| {
        if matches!(event, tauri::RunEvent::Exit) {
            if let Some(state) = app_handle.try_state::<Arc<HostRuntime>>() {
                state.shutdown_all();
            }
            logging::record_clean_exit();
        }
    });
}

#[cfg(desktop)]
fn install_global_shortcut(app: &AppHandle) -> AppResult<()> {
    let shortcut = default_shortcut();
    let watched_shortcut = shortcut.clone();

    app.plugin(
        tauri_plugin_global_shortcut::Builder::new()
            .with_handler(move |app, triggered_shortcut, event| {
                if triggered_shortcut == &watched_shortcut
                    && matches!(event.state(), ShortcutState::Pressed)
                {
                    let _ = toggle_main_window(app, "home");
                }
            })
            .build(),
    )
    .map_err(|error| {
        AppError::InvalidInput(format!(
            "failed to initialize global shortcut plugin: {error}"
        ))
    })?;

    app.global_shortcut().register(shortcut).map_err(|error| {
        AppError::InvalidInput(format!("failed to register global shortcut: {error}"))
    })?;

    Ok(())
}

#[cfg(desktop)]
fn install_tray(app: &AppHandle) -> AppResult<()> {
    let menu = MenuBuilder::new(app)
        .text("toggle", "Show / Hide")
        .text("new_room", "Open pastey")
        .separator()
        .text("quit", "Quit")
        .build()
        .map_err(|error| AppError::InvalidInput(format!("failed to build tray menu: {error}")))?;

    let icon = app
        .default_window_icon()
        .ok_or_else(|| AppError::InvalidInput("missing default window icon".into()))?
        .clone();

    TrayIconBuilder::new()
        .icon(icon)
        .menu(&menu)
        .on_menu_event(|app, event| match event.id.as_ref() {
            "toggle" | "new_room" => {
                let _ = toggle_main_window(app, "home");
            }
            "quit" => {
                app.exit(0);
            }
            _ => {}
        })
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                let _ = toggle_main_window(tray.app_handle(), "home");
            }
        })
        .build(app)
        .map_err(|error| AppError::InvalidInput(format!("failed to create tray icon: {error}")))?;

    Ok(())
}

#[cfg(desktop)]
fn toggle_main_window(app: &AppHandle, target: &str) -> AppResult<()> {
    let window = app
        .get_webview_window("main")
        .ok_or_else(|| AppError::NotFound("main window not found".into()))?;
    let is_visible = window.is_visible().map_err(|error| {
        AppError::InvalidInput(format!("failed to read window visibility: {error}"))
    })?;

    if is_visible {
        window
            .hide()
            .map_err(|error| AppError::InvalidInput(format!("failed to hide window: {error}")))?;
        let state = app.state::<Arc<HostRuntime>>().inner().clone();
        let task_state = state.clone();
        state.spawn(async move {
            discovery::stop_antenna(task_state).await;
        });
    } else {
        window
            .show()
            .map_err(|error| AppError::InvalidInput(format!("failed to show window: {error}")))?;
        let state = app.state::<Arc<HostRuntime>>().inner().clone();
        let task_state = state.clone();
        state.spawn(async move {
            if discovery::ensure_service(task_state.clone()).await.is_ok() {
                discovery::start_antenna(task_state).await;
            }
        });
        let _ = window.unminimize();
        let _ = window.set_focus();
        app.emit(
            "pastey://focus",
            serde_json::json!({
                "target": target
            }),
        )
        .map_err(|error| AppError::InvalidInput(format!("failed to emit focus event: {error}")))?;
    }

    Ok(())
}

#[cfg(desktop)]
fn default_shortcut() -> Shortcut {
    let modifiers = if cfg!(target_os = "macos") {
        Modifiers::SUPER | Modifiers::SHIFT
    } else {
        Modifiers::CONTROL | Modifiers::SHIFT
    };
    Shortcut::new(Some(modifiers), Code::KeyV)
}

#[cfg(desktop)]
fn default_shortcut_label() -> &'static str {
    "CommandOrControl+Shift+V"
}

/// A phone has no global shortcut. The label is only shown, never parsed.
#[cfg(mobile)]
fn default_shortcut_label() -> &'static str {
    "Unavailable on this device"
}

fn desktop_app_paths(app: &AppHandle) -> AppResult<AppPaths> {
    let default_app_data_dir = app.path().app_data_dir().map_err(|error| {
        AppError::InvalidInput(format!("unable to resolve app data directory: {error}"))
    })?;
    let app_data_dir_override = desktop_app_data_dir_override()?;
    let app_data_dir = app_data_dir_override
        .clone()
        .unwrap_or(default_app_data_dir);
    let logs_dir = app_data_dir_override
        .as_ref()
        .map(|dir| dir.join("logs"))
        .unwrap_or_else(|| desktop_default_logs_dir(&app_data_dir));
    let paths = AppPaths::new(app_data_dir, logs_dir);
    paths.ensure_directories()?;
    Ok(paths)
}

fn desktop_app_data_dir_override() -> AppResult<Option<PathBuf>> {
    let Some(value) = std::env::var_os(APP_DATA_DIR_ENV) else {
        return Ok(None);
    };
    let display = value.to_string_lossy();
    if display.trim().is_empty() {
        return Err(AppError::InvalidInput(format!(
            "{APP_DATA_DIR_ENV} must not be empty"
        )));
    }
    let path = PathBuf::from(value);
    if path.is_absolute() {
        Ok(Some(path))
    } else {
        Ok(Some(std::env::current_dir()?.join(path)))
    }
}

fn desktop_default_logs_dir(app_data_dir: &std::path::Path) -> PathBuf {
    #[cfg(target_os = "macos")]
    {
        if let Some(home) = std::env::var_os("HOME") {
            return PathBuf::from(home)
                .join("Library")
                .join("Application Support")
                .join("pastey")
                .join("logs");
        }
    }

    #[cfg(target_os = "windows")]
    {
        if let Some(local_app_data) = std::env::var_os("LOCALAPPDATA") {
            return PathBuf::from(local_app_data).join("pastey").join("logs");
        }
    }

    app_data_dir.join("logs")
}

/// What one start of this executable is for, once the helper modes above
/// (Windows sandbox setup, the Claude Code lifeline) have had their turn.
#[cfg(desktop)]
#[derive(Debug, PartialEq, Eq)]
enum LaunchMode {
    /// No arguments: the desktop app.
    Desktop,
    /// An argument the desktop app does not take.
    Refused(String),
}

#[cfg(desktop)]
fn launch_mode(arguments: impl IntoIterator<Item = std::ffi::OsString>) -> LaunchMode {
    for argument in arguments {
        let text = argument.to_string_lossy();
        // Older macOS Launch Services passed a process serial number.
        if text.starts_with("-psn_") {
            continue;
        }
        return LaunchMode::Refused(text.into_owned());
    }
    LaunchMode::Desktop
}

#[cfg(all(test, desktop))]
mod launch_mode_tests {
    use super::{launch_mode, LaunchMode};
    use std::ffi::OsString;

    fn mode(arguments: &[&str]) -> LaunchMode {
        launch_mode(arguments.iter().map(OsString::from))
    }

    #[test]
    fn no_arguments_start_the_desktop_app() {
        assert_eq!(mode(&[]), LaunchMode::Desktop);
        assert_eq!(mode(&["-psn_0_12345"]), LaunchMode::Desktop);
    }

    #[test]
    fn a_retired_mcp_entry_is_refused_rather_than_opening_the_app() {
        assert_eq!(
            mode(&["--physical-mcp", "/tmp/grant.json"]),
            LaunchMode::Refused("--physical-mcp".into())
        );
    }

    #[test]
    fn any_other_argument_is_refused() {
        assert_eq!(
            mode(&["--anything"]),
            LaunchMode::Refused("--anything".into())
        );
        assert_eq!(mode(&["file.txt"]), LaunchMode::Refused("file.txt".into()));
        assert_eq!(
            mode(&["-psn_0_1", "--x"]),
            LaunchMode::Refused("--x".into())
        );
    }
}
