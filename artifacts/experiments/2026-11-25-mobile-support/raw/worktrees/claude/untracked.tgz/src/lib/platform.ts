/** Which kind of device this window runs on, so the screens can leave out what
 * a phone cannot do (sharing folders, running an Agent here, a native folder
 * window) and use what it can (the system's file picker). A convenience for
 * the renderer only: it never decides what a device may do. Rust's own
 * `cfg(desktop)` / `cfg(mobile)` build split is authoritative for that
 * (docs/research/mobile-support.md). */

export type DevicePlatform = "desktop" | "ios" | "android";

/** `?platform=ios` (or `android`, `desktop`) in the address, for looking at a
 * phone's screens in a desktop browser. A packaged app has no query. */
function forcedPlatform(): DevicePlatform | null {
  if (typeof window === "undefined" || !window.location) return null;
  try {
    const value = new URLSearchParams(window.location.search).get("platform");
    return value === "ios" || value === "android" || value === "desktop" ? value : null;
  } catch {
    return null;
  }
}

/** The platform a user agent and its touch points describe. */
export function platformOfUserAgent(agent: string, touchPoints: number): DevicePlatform {
  if (/Android/i.test(agent)) return "android";
  if (/iPhone|iPad|iPod/i.test(agent)) return "ios";
  // iPadOS asks for desktop sites by default and then reports a Mac; a Mac
  // has no touch screen.
  if (/Macintosh/.test(agent) && touchPoints > 1) return "ios";
  return "desktop";
}

export function devicePlatform(): DevicePlatform {
  const forced = forcedPlatform();
  if (forced) return forced;
  if (typeof navigator === "undefined") return "desktop";
  return platformOfUserAgent(navigator.userAgent || "", navigator.maxTouchPoints || 0);
}

export function isMobilePlatform(): boolean {
  return devicePlatform() !== "desktop";
}
