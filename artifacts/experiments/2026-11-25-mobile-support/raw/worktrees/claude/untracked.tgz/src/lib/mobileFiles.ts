/** Sending files from a phone. A phone's file picker gives the page a `File`,
 * not a path Pastey can read: on Android the system returns a `content://`
 * address, and on iOS a copy only the picker's process may have opened. So the
 * page reads the bytes and hands them to Pastey, which keeps them in this
 * device's temp folder and sends that file like any other (the temp file is
 * deleted when the send ends). See docs/research/mobile-support.md, "Sending". */
import { writeTempFileRaw } from "./tauri";
import type { TransferQueueInput } from "./transferScheduler";

/** The biggest file read whole into memory this way. A phone cannot hold much
 * more than this twice (the page's copy, then Pastey's); a chunked hand-over
 * would lift it (mobile-support.md, milestone M2). */
export const PHONE_FILE_LIMIT_BYTES = 64 * 1024 * 1024;

export type StagedFile = Required<
  Pick<TransferQueueInput, "path" | "displayName" | "sizeBytes" | "modifiedMs">
> & Pick<TransferQueueInput, "mimeType" | "deleteWhenDone">;

export interface StagedFiles {
  staged: StagedFile[];
  /** Names of files over the limit, left out. */
  tooLarge: string[];
  /** Names of files that could not be read or stored, left out. */
  failed: string[];
}

/** Opens the system's file picker. Must be called straight from a tap: a
 * browser or WebView refuses to open a picker later than the tap's own turn. */
export function pickFilesFromDevice(): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.multiple = true;
    input.style.display = "none";
    const finish = (files: File[]) => {
      input.remove();
      resolve(files);
    };
    input.addEventListener("change", () => finish(Array.from(input.files ?? [])), { once: true });
    // Not every WebView reports a dismissed picker; then this stays pending
    // and holds nothing but itself.
    input.addEventListener("cancel", () => finish([]), { once: true });
    document.body.appendChild(input);
    input.click();
  });
}

/** Stores each picked file in the temp folder, ready to queue. */
export async function stagePickedFiles(
  files: File[],
  limit: number = PHONE_FILE_LIMIT_BYTES,
): Promise<StagedFiles> {
  const result: StagedFiles = { staged: [], tooLarge: [], failed: [] };
  for (const file of files) {
    if (file.size > limit) {
      result.tooLarge.push(file.name);
      continue;
    }
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const path = await writeTempFileRaw(file.name, bytes);
      result.staged.push({
        path,
        displayName: file.name,
        mimeType: file.type || null,
        sizeBytes: file.size,
        modifiedMs: file.lastModified,
        deleteWhenDone: true,
      });
    } catch {
      result.failed.push(file.name);
    }
  }
  return result;
}

/** One line telling the user what was left out, or null if nothing was. */
export function skippedFilesMessage(staged: StagedFiles, limit: number = PHONE_FILE_LIMIT_BYTES): string | null {
  const parts: string[] = [];
  if (staged.tooLarge.length > 0) {
    parts.push(`${listNames(staged.tooLarge)} ${staged.tooLarge.length === 1 ? "is" : "are"} over ${Math.round(limit / (1024 * 1024))} MB, the most a phone sends for now`);
  }
  if (staged.failed.length > 0) {
    parts.push(`${listNames(staged.failed)} could not be read`);
  }
  return parts.length > 0 ? `${parts.join("; ")}.` : null;
}

function listNames(names: string[]): string {
  return names.length <= 2 ? names.join(" and ") : `${names[0]} and ${names.length - 1} more`;
}
