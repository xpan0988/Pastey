# claude results (L=3, all full-tier PASS, exhaustive in this model)
| circuit | T | Q | SHA-256 | regenerate |
|---|---|---|---|---|
| L3_phase_direct.kmx | 203 | 63 | f24db08c24ede1e9852750da95800979b09177fc5c42505c4ebe019c6305b686 | python3 work/claude/gen_phase_direct.py |
| L3_phase_direct2.kmx | 167 | 63 | 38d514fdca68717b83fb3487be0808dc68f964f1a7713bc5574423e0ae41533b | python3 work/claude/gen_phase_direct2.py |
Verify: python3 verify.py <file> --tier full. Recurrence cross-check over all of Omega_3: python3 work/claude/check_direct.py
Key ideas: (1) phase M.h is linear/bilinear in the inverse registers -> conditioned Z/CZ (free), no head multiplies;
(2) erase inverse registers by HMR, pay degree-7 phase with a phase-only inversion (26 T).
Independent reproduction: codex regenerated the 203 method with different bytes (its report); matching hash not yet confirmed.
