"""Cross-check of the direct head recurrence (codex's formula) against spec.reference over ALL of Omega_3."""
import sys, numpy as np
sys.path.insert(0,'lib/qlab'); import spec, gf
from ref import MUL, INV
L=3; c=spec.code(L)
x=np.arange(1<<24,dtype=np.int64)
v,heads,valid=spec.reference(x,L)
HE=lambda i,k:np.array([c.head_eval(i,k,A) for A in range(256)],dtype=np.int64)
d1=v[1]^HE(0,1)[v[0]]; d2=v[2]^HE(0,2)[v[0]]
h1=MUL[c.p(0,c.c[1])][INV[d1]]
den=c.p(0,c.c[2])^MUL[HE(1,2)[h1],d2]
h2=MUL[MUL[c.p(1,c.c[2]),d2],INV[den]]
ok=valid
print('valid',ok.sum(),'h1 match',(h1[ok]==heads[1][ok]).all(),'h2 match',(h2[ok]==heads[2][ok]).all())
print('valid iff d1!=0 and den!=0:',((d1!=0)&(den!=0)==ok).all())
