"""claude: direct out-of-place L=3 stage with *free bilinear phase* (conditioned CZ), no head multiplies.
Regenerate: python3 work/claude/gen_phase_direct.py  -> work/claude/L3_phase_direct.kmx
Idea: phase M.h1 is linear in I1=1/d1; phase M.h2 = M.(q d2 I2) is bilinear in (d2, I2) -> conditioned CZs (Clifford, free).
"""
import sys, hashlib
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'lib'/'qlab')); sys.path.insert(0, str(ROOT/'baselines'))
import gf, spec
from gen import Gen, bits_of
from e17_variants import to_kmx

def cmat(c): return gf.lin_matrix(lambda x: gf.mul(c, x))
def comp(A, B):  # rows of A∘B (apply B then A)
    return [Gen.compose(A[i], B) for i in range(len(A))]

def build(L=3):
    assert L == 3
    code = spec.code(L); c = code.c
    g = Gen()
    B = [g.alloc(8) for _ in range(L)]
    v0, v1, v2 = B
    masks = [g.bit() for _ in range(8*L)]
    L01, L02, L12 = code.L(0,1), code.L(0,2), code.L(1,2)
    P1 = cmat(code.p(0, c[1])); Q = cmat(code.p(1, c[2])); p02 = code.p(0, c[2])
    # h0 phase
    for i in range(8): g.Z(v0[i], masks[i])
    g.lin_into(v1, v0, L01)                       # v1 = d1
    I1 = g.alloc(8); g.inv_into(I1, v1)           # I1 = 1/d1 ; h1 = P1 I1
    for i in range(8):                            # M1.h1 = (P1^T M1).I1
        bs = [masks[8+j] for j in range(8) if (P1[j] >> i) & 1]
        if bs: g.Z(I1[i], g.parity_bit(bs))
    g.lin_into(v2, v0, L02)                       # v2 = d2
    den = g.alloc(8)
    for i in range(8):
        if (p02 >> i) & 1: g.X(den[i])
    Lx = comp(L12, P1)
    g.mul_acc(den, I1, v2, Lx=Lx)                 # den = p0(c2) + L12(h1) d2
    I2 = g.alloc(8); g.inv_into(I2, den)          # h2 = q d2 I2
    for (r1, m1, r2, m2, w) in g.bilinear_terms(v2, I2, Lx=Q):
        cb = g.parity_bit([masks[16+i] for i in bits_of(w)])
        a1, u1 = g.form(r1, m1); a2, u2 = g.form(r2, m2)
        g.CZ(a1, a2, cb); u2(); u1()
    g.inv_into(I2, den); g.free(I2)               # uncompute I2
    for i in range(8):
        if (p02 >> i) & 1: g.X(den[i])
    g.erase(den, terms=g.bilinear_terms(I1, v2, Lx=Lx)); g.free(den)
    g.lin_into(v2, v0, L02)
    g.inv_into(I1, v1); g.free(I1)
    g.lin_into(v1, v0, L01)
    return g, masks

if __name__ == '__main__':
    g, masks = build()
    s = to_kmx(g, masks, 3, 'claude phase_direct L=3')
    out = Path(__file__).with_name('L3_phase_direct.kmx'); out.write_text(s)
    print('T', g.tof, 'peak', g.peak, 'phys', g.nq, 'sha256(file)', hashlib.sha256(s.encode()).hexdigest())
