"""L=3 bilinear mask phases with selectable inversion workspace retention."""
import argparse
from pathlib import Path

from direct import Gen, Node, bits_of, spec, to_kmx
import gf


def product_phase(g, phases, x, y, terms, output_rows=None):
    for _, u, _, v, w in terms:
        if output_rows is not None:
            w = sum(((row & w).bit_count() % 2) << i
                    for i, row in enumerate(output_rows))
        if w:
            condition = g.parity_bit([phases[i] for i in bits_of(w)])
            left, undo_left = g.form(x, u)
            right, undo_right = g.form(y, v)
            g.CZ(left, right, condition)
            undo_right()
            undo_left()


def inverse(g, target, d, mode, phase_half=None):
    if mode == "recompute":
        g.inv_into(target, d)
        return lambda: g.inv_into(target, d)

    if mode == "phase":
        g.inv_into(target, d)

    lo, hi = d[:4], d[4:]
    square = gf.lin_matrix(lambda x: gf.power(x, 2, 4), 4)
    fourth = gf.lin_matrix(lambda x: gf.power(x, 4, 4), 4)
    eighth = gf.lin_matrix(lambda x: gf.power(x, 8, 4), 4)
    beta_square = gf.lin_matrix(
        lambda x: gf.mul(gf.BETAS[4], gf.power(x, 2, 4), 4), 4)
    add_halves = [(1 << i) | (1 << (i + 4)) for i in range(4)]
    def norm_workspace():
        norm = g.alloc(4)
        g.lin_into(norm, lo, square)
        g.lin_into(norm, hi, beta_square)
        g.mul_acc(norm, lo, hi, m=4)
        sixth = g.alloc(4)
        g.mul_acc(sixth, norm, norm, Lx=square, Ly=fourth, m=4)
        norm_inverse = g.alloc(4)
        g.mul_acc(norm_inverse, sixth, norm, Ly=eighth, m=4)
        return norm, sixth, norm_inverse

    if mode != "phase":
        norm, sixth, norm_inverse = norm_workspace()
        if mode == "split":
            for offset, source, rows in ((0, d, add_halves), (4, hi, None)):
                half = g.alloc(4)
                g.mul_acc(half, source, norm_inverse, Lx=rows, m=4)
                phase_half(half, offset)
                g.erase(half, g.bilinear_terms(source, norm_inverse, Lx=rows, m=4))
                g.free(half)
        else:
            g.mul_acc(target[:4], d, norm_inverse, Lx=add_halves, m=4)
            g.mul_acc(target[4:], hi, norm_inverse, m=4)
        if mode == "partial":
            g.erase(sixth, g.bilinear_terms(norm, norm, Lx=square, Ly=fourth, m=4))
            g.free(sixth)

    def cleanup():
        if mode == "phase":
            phases = [g.HMR(q) for q in target]
            current_norm, current_sixth, current_inverse = norm_workspace()
            product_phase(g, phases[:4], d, current_inverse,
                          g.bilinear_terms(d, current_inverse, Lx=add_halves, m=4))
            product_phase(g, phases[4:], hi, current_inverse,
                          g.bilinear_terms(hi, current_inverse, m=4))
        else:
            current_norm, current_inverse = norm, norm_inverse
            current_sixth = sixth
            if mode == "partial":
                current_sixth = g.alloc(4)
                g.mul_acc(current_sixth, norm, norm, Lx=square, Ly=fourth, m=4)
            if mode != "split":
                g.erase(target[:4], g.bilinear_terms(d, norm_inverse, Lx=add_halves, m=4))
                g.erase(target[4:], g.bilinear_terms(hi, norm_inverse, m=4))
        g.erase(current_inverse, g.bilinear_terms(current_sixth, current_norm, Ly=eighth, m=4))
        g.free(current_inverse)
        g.erase(current_sixth, g.bilinear_terms(current_norm, current_norm, Lx=square, Ly=fourth, m=4))
        g.free(current_sixth)
        linear = [(reg, row, 1 << i)
                  for reg, rows in ((lo, square), (hi, beta_square))
                  for i, row in enumerate(rows)]
        g.erase(current_norm, g.bilinear_terms(lo, hi, m=4), linear=linear)
        g.free(current_norm)

    return cleanup


def build(modes):
    g = Gen()
    v0, d1, d2 = (g.alloc(8) for _ in range(3))
    masks = [g.bit() for _ in range(24)]
    code = spec.code(3)
    first, second = Node(code, 1), Node(code, 2)
    for q, mask in zip(v0, masks):
        g.Z(q, mask)
    g.lin_into(d1, v0, first.L[0])
    g.lin_into(d2, v0, second.L[0])
    inv1 = g.alloc(8)
    clean1 = inverse(g, inv1, d1, modes[0])
    for i, q in enumerate(inv1):
        phase = [mask for mask, row in zip(masks[8:16], first.P[0])
                 if row & (1 << i)]
        g.Z(q, g.parity_bit(phase))
    head_eval = [g.compose(row, first.P[0]) for row in second.L[1]]
    den = g.alloc(8)
    g.mul_acc(den, inv1, d2, Lx=head_eval)
    for i in bits_of(second.p[0]):
        g.X(den[i])
    if modes[1] == "split":
        def phase_half(half, offset):
            embed = [1 << (i - offset) if offset <= i < offset + 4 else 0
                     for i in range(8)]
            terms = g.bilinear_terms(d2, half, Ly=embed)
            product_phase(g, masks[16:], d2, half, terms, second.P[1])

        inverse(g, None, den, "split", phase_half)()
    else:
        inv2 = g.alloc(8)
        clean2 = inverse(g, inv2, den, modes[1])
        product_phase(g, masks[16:], d2, inv2, g.bilinear_terms(d2, inv2), second.P[1])
        clean2()
        g.free(inv2)
    for i in bits_of(second.p[0]):
        g.X(den[i])
    g.erase(den, g.bilinear_terms(inv1, d2, Lx=head_eval))
    g.free(den)
    clean1()
    g.free(inv1)
    g.lin_into(d2, v0, second.L[0])
    g.lin_into(d1, v0, first.L[0])
    return to_kmx(g, masks, 3, 'L=3 bilinear phases with selectable inverse cleanup')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    modes = {
        'none': ('recompute', 'recompute'),
        'second': ('recompute', 'retain'),
        'both': ('retain', 'retain'),
        'partial-first': ('partial', 'retain'),
        'phase-first': ('phase', 'retain'),
        'split': ('retain', 'split'),
        'split-partial': ('partial', 'split'),
        'split-phase': ('phase', 'split'),
    }
    parser.add_argument('--retain', choices=modes, default='second')
    args = parser.parse_args()
    args.output.write_bytes(build(modes[args.retain]).encode('ascii'))
