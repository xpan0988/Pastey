"""Generate an L=3 phase circuit from the two closed-form heads."""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from baselines.e17_variants import Gen, spec, to_kmx
from proto import Node
from gen import bits_of


def build(quadratic_erase):
    g = Gen()
    v0, d1, d2 = (g.alloc(8) for _ in range(3))
    masks = [g.bit() for _ in range(24)]
    code = spec.code(3)
    first, second = Node(code, 1), Node(code, 2)

    for q, mask in zip(v0, masks):
        g.Z(q, mask)
    g.lin_into(d1, v0, first.L[0])
    g.lin_into(d2, v0, second.L[0])
    head1 = g.alloc(8)
    g.inv_into(head1, d1)
    g.const_mul_inplace(head1, first.P[0])
    for q, mask in zip(head1, masks[8:16]):
        g.Z(q, mask)

    denominator = g.alloc(8)
    g.mul_acc(denominator, head1, d2, Lx=second.L[1])
    for i in bits_of(second.p[0]):
        g.X(denominator[i])
    reciprocal = g.alloc(8)
    g.inv_into(reciprocal, denominator)

    head2 = g.alloc(8)
    g.mul_acc(head2, d2, reciprocal, out_rows=second.P[1])
    for q, mask in zip(head2, masks[16:]):
        g.Z(q, mask)
    g.const_mul_inplace(head2, second.Pi[1])
    if quadratic_erase:
        g.erase(head2, g.bilinear_terms(d2, reciprocal))
    else:
        g.mul_acc(head2, d2, reciprocal)
    g.free(head2)

    g.inv_into(reciprocal, denominator)
    g.free(reciprocal)
    for i in bits_of(second.p[0]):
        g.X(denominator[i])
    if quadratic_erase:
        g.erase(denominator, g.bilinear_terms(head1, d2, Lx=second.L[1]))
    else:
        g.mul_acc(denominator, head1, d2, Lx=second.L[1])
    g.free(denominator)
    g.const_mul_inplace(head1, first.Pi[0])
    g.inv_into(head1, d1)
    g.free(head1)
    g.lin_into(d2, v0, second.L[0])
    g.lin_into(d1, v0, first.L[0])
    return to_kmx(g, masks, 3, 'Direct L=3 phase oracle')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--recompute-products', action='store_true')
    args = parser.parse_args()
    args.output.write_bytes(build(not args.recompute_products).encode('ascii'))
