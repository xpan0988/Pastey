"""L=3 forwarded_old_value stage with the 24-AND GF(256) multiplier.
   python3 work/claude/gen_stage24.py   -> work/claude/L3_fov_mul24.kmx"""
import sys, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'baselines'))
import patch24
import e17_variants as E
g, masks, info = E.build('forwarded_old_value', 3)
p = HERE / 'L3_fov_mul24.kmx'
p.write_text(E.to_kmx(g, masks, 3, 'forwarded_old_value with 24-AND GF(256) mul (work/claude/gen_stage24.py)'))
print(info['toffolis'], info['peak_live_qubits'], hashlib.sha256(p.read_bytes()).hexdigest())
