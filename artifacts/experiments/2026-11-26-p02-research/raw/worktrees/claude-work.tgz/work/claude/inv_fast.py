"""Cheaper GF(256) inversion: GF(16) inverse via GF(4) norm (3+6 ANDs instead of 18). Out-of-place t ^= inv(d), inv(0)=0.
Toffolis: 9 (GF16 norm of d... see below) -> total 3+... measured by gen.tof."""
import patch24  # noqa (sets paths; mul gadget irrelevant for m<=4)
import gf
from gen import Gen

def inv_into_fast(g, t, d):
    lo, hi = d[:4], d[4:]
    sq = gf.lin_matrix(lambda x: gf.mul(x, x, 4), 4)
    beta = gf.BETAS[4]
    n = g.alloc(4)
    bsq = gf.lin_matrix(lambda x: gf.mul(beta, gf.mul(x, x, 4), 4), 4)
    g.lin_into(n, lo, sq); g.lin_into(n, hi, bsq)
    g.mul_acc(n, lo, hi, m=4)                     # n = norm(d) in GF(16)   (9 ANDs)
    W = gf.BETAS[2]
    sq2 = gf.lin_matrix(lambda x: gf.mul(x, x, 2), 2)
    wsq2 = gf.lin_matrix(lambda x: gf.mul(W, gf.mul(x, x, 2), 2), 2)
    a, b = n[:2], n[2:]
    N2 = g.alloc(2)                               # N = a^2 + ab + W b^2 in GF(4)
    g.lin_into(N2, a, sq2); g.lin_into(N2, b, wsq2)
    g.mul_acc(N2, a, b, m=2)                      # 3 ANDs
    # ni = n^-1 = ((a+b) + b y) * N^2
    ni = g.alloc(4)
    apb = [0b0101, 0b1010]                        # rows over n (4 bits): a_i + b_i
    bb = [0b0100, 0b1000]
    g.mul_acc(ni[:2], n, N2, Lx=apb, Ly=sq2, m=2)
    g.mul_acc(ni[2:], n, N2, Lx=bb, Ly=sq2, m=2)
    add = [(1 << i) | (1 << (i + 4)) for i in range(4)]
    g.mul_acc(t[:4], d, ni, Lx=add, m=4)
    g.mul_acc(t[4:], hi, ni, m=4)
    ter = g.bilinear_terms(n, N2, Lx=apb, Ly=sq2, m=2)
    ter2 = [(r1, m1, r2, m2, w << 2) for (r1, m1, r2, m2, w) in g.bilinear_terms(n, N2, Lx=bb, Ly=sq2, m=2)]
    g.erase(ni, terms=ter + ter2); g.free(ni)
    lin = [(a, sq2[i], 1 << i) for i in range(2)] + [(b, wsq2[i], 1 << i) for i in range(2)]
    g.erase(N2, terms=g.bilinear_terms(a, b, m=2), linear=lin); g.free(N2)
    lin = [(lo, sq[i], 1 << i) for i in range(4)] + [(hi, bsq[i], 1 << i) for i in range(4)]
    g.erase(n, terms=g.bilinear_terms(lo, hi, m=4), linear=lin); g.free(n)

if __name__ == '__main__':
    from pathlib import Path
    HERE = Path(__file__).resolve().parent
    g = Gen(); d, t = g.alloc(8), g.alloc(8); inv_into_fast(g, t, d)
    r = lambda n, qs, k: f'#{k} {n} ' + ' '.join(f'q{q}' for q in qs)
    (HERE / 'gf256_inv_fast.kmx').write_text('\n'.join(['# inv via GF(4) norm', r('d', d, 'in'), r('out', t, 'out')] + g.lines) + '\n')
    print('toffoli', g.tof, 'peak', g.peak)
