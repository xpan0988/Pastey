"""L=3 forwarded_old_value stage with 24-AND mul and 36-T inversion -> work/claude/L3_fov_mul24_inv36.kmx"""
import sys, hashlib
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'baselines'))
import patch24, inv_fast
from gen import Gen
Gen.inv_into = lambda self, t, d: inv_fast.inv_into_fast(self, t, d)
import e17_variants as E
g, masks, info = E.build('forwarded_old_value', 3)
p = HERE / 'L3_fov_mul24_inv36.kmx'
p.write_text(E.to_kmx(g, masks, 3, 'fov with mul24 + inv36 (work/claude/gen_stage24_inv36.py)'))
print(info['toffolis'], info['peak_live_qubits'], hashlib.sha256(p.read_bytes()).hexdigest())
