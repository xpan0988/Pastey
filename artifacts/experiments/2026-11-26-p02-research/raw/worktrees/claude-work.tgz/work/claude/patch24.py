"""Import before gen use: replaces gf.bilinear(8) with the 24-AND algorithm."""
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE.parents[1] / 'lib' / 'qlab'))
import gf, mul24
_orig = gf.bilinear
_T = mul24.find()[0]
def bilinear(m=8):
    return list(_T) if m == 8 else _orig(m)
gf.bilinear = bilinear
