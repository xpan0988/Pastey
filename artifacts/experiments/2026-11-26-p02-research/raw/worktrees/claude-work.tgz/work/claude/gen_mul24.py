import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
import patch24
from gen import Gen
g = Gen(); x, y, o = g.alloc(8), g.alloc(8), g.alloc(8); g.mul_acc(o, x, y)
r = lambda n, qs, k: f'#{k} {n} ' + ' '.join(f'q{q}' for q in qs)
(HERE / 'gf256_mul_acc24.kmx').write_text('\n'.join(['# mul_acc with 24-AND algorithm', r('x', x, 'in'), r('y', y, 'in'), r('out', o, 'out')] + g.lines) + '\n')
print('toffoli', g.tof)
