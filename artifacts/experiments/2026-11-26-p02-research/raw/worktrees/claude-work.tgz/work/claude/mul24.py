"""24-AND bilinear algorithm for GF(256) (tower basis) multiplication: GF(256)=GF(4)[th]/(quartic),
product coefficients c_0..c_6 recovered from evaluations at the 4 points of GF(4), infinity, and one quadratic modulus
(8 GF(4) products x 3 ANDs). Returns triples (u,v,w) like gf.bilinear(8)."""
import sys, itertools
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'lib' / 'qlab'))
import gf

def g4(x, y): return gf.mul(x, y, 2)
def rank_solve(rows, target):
    """GF(2): find combination of rows (ints) equal to target; return mask of used rows or None."""
    basis = []  # (vec, combo)
    for i, r in enumerate(rows):
        c = 1 << i
        for b, bc in basis:
            if r ^ b < r: r ^= b; c ^= bc
        if r: basis.append((r, c)); basis.sort(reverse=True)
    t, c = target, 0
    for b, bc in basis:
        if t ^ b < t: t ^= b; c ^= bc
    return c if t == 0 else None

def build():
    # GF(4) subfield of tower GF(256): elements with bits only in low 2 bits (embedding of GF(4)).
    # find theta of degree 4 over GF(4): powers 1,th,th2,th3 GF(4)-independent
    emb = lambda a: a  # GF(4) element a (0..3) is tower element a
    def span4(vs):
        S = {0}
        for v in vs:
            S = {s ^ gf.mul(a, v) for s in S for a in range(4)}
        return len(S)
    th = next(t for t in range(4, 256) if span4([1, t, gf.mul(t, t), gf.power(t, 3)]) == 256)
    P = [1, th, gf.mul(th, th), gf.power(th, 3)]
    # coordinate map: x (8 bits) -> (x_0..x_3) in GF(4)^4, GF(2)-linear; build via table
    coord = {}
    for xs in itertools.product(range(4), repeat=4):
        v = 0
        for a, p in zip(xs, P): v ^= gf.mul(a, p)
        coord[v] = xs
    def coordbits(i, bit):   # mask over x's 8 bits giving bit `bit` of coordinate i
        m = 0
        for j in range(8):
            if (coord[1 << j][i] >> bit) & 1: m |= 1 << j
        return m
    # linear forms: coordinate i bits -> masks
    Cf = [[coordbits(i, b) for b in range(2)] for i in range(4)]   # Cf[i][b]: mask
    def gf4_lin(coefs):
        """GF(4)-linear combination sum_i a_i X_i (a_i in GF(4)) -> two masks (bit0,bit1)."""
        out = [0, 0]
        for i, a in enumerate(coefs):
            if a == 0: continue
            # a * X_i where X_i = (b0,b1): result bits as GF(2)-linear in (b0,b1)
            for b in range(2):
                r = g4(a, 1 << b)           # image of basis element
                for ob in range(2):
                    if (r >> ob) & 1: out[ob] ^= Cf[i][b]
        return out
    prods = []   # list of (xmask-pair, ymask-pair)
    pts = [(a, a2) for a in range(4) for a2 in [1]]
    for a in range(4):
        pw = [1, a, g4(a, a), g4(a, g4(a, a))]
        prods.append((gf4_lin(pw), gf4_lin(pw)))
    prods.append((gf4_lin([0, 0, 0, 1]), gf4_lin([0, 0, 0, 1])))   # infinity (coefficient of t^3)
    # quad modulus q = t^2 + t + w (irreducible over GF(4)? choose by search below); x mod q = x0+x1 t + x2 t^2+x3 t^3 reduced
    return th, P, coord, gf4_lin, prods

def find():
    th, P, coord, gf4_lin, prods = build()
    # try irreducible quads q=t^2+s t+r over GF(4) (no roots)
    for s in range(4):
        for r in range(1, 4):
            if any(g4(a, a) ^ g4(s, a) ^ r == 0 for a in range(4)): continue
            # t^2 = s t + r ; t^3 = s t^2 + r t = (s^2+r) t + s r
            t2 = (r, s); t3 = (g4(s, r), g4(s, s) ^ r)
            # reduced coords: (c0,c1) = x0 + x2*r + x3*sr ..., c1 = x1 + x2*s + x3*(s^2+r)
            red = [[1, 0, t2[0], t3[0]], [0, 1, t2[1], t3[1]]]
            xs = [gf4_lin(red[0]), gf4_lin(red[1])]      # each: two masks (bit0, bit1) of GF(4) elt X0 and X1
            # product of (X0 + X1 t)(Y0 + Y1 t) mod nothing needed: use Karatsuba on full poly: 3 GF(4) mults
            # p0=X0Y0, p1=X1Y1, p2=(X0+X1)(Y0+Y1)
            sumx = [xs[0][b] ^ xs[1][b] for b in range(2)]
            quad = [(xs[0], xs[0]), (xs[1], xs[1]), (sumx, sumx)]
            allp = prods + quad
            ands = []
            for X, Y in allp:      # GF(4) Karatsuba: bits X0,X1
                ands += [(X[0], Y[0]), (X[1], Y[1]), (X[0] ^ X[1], Y[0] ^ Y[1])]
            # solve w for each of 8 output bits: bilinear form matrix flattened 64 bits
            def form(u, v): return sum(((bin(u & (1 << i)).count('1') & 1) and (v >> j) & 1) << (8 * i + j)
                                       for i in range(8) for j in range(8))
            forms = [form(u, v) for u, v in ands]
            ws = [0] * len(ands); ok = True
            for ob in range(8):
                tgt = 0
                for i in range(8):
                    for j in range(8):
                        if (gf.mul(1 << i, 1 << j) >> ob) & 1: tgt |= 1 << (8 * i + j)
                c = rank_solve(forms, tgt)
                if c is None: ok = False; break
                for k in range(len(ands)):
                    if (c >> k) & 1: ws[k] |= 1 << ob
            if ok:
                return [(u, v, w) for (u, v), w in zip(ands, ws)], (s, r)
    return None, None

if __name__ == '__main__':
    t, qr = find()
    if t is None: print('no decomposition'); sys.exit(1)
    nz = [x for x in t if x[2]]
    print('quad', qr, 'terms', len(t), 'nonzero-w', len(nz))
    # verify
    import random
    for _ in range(20000):
        x, y = random.randrange(256), random.randrange(256); o = 0
        for u, v, w in t:
            if (bin(u & x).count('1') & 1) and (bin(v & y).count('1') & 1): o ^= w
        assert o == gf.mul(x, y)
    print('verified')
