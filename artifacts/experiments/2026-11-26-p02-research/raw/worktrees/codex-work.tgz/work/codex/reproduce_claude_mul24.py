"""Generate the closed-form stage using the multiplier terms sent by Claude."""
import argparse
from pathlib import Path
from unittest.mock import patch

from closed_form import build, gf


# In the frozen GF(256) tower basis. Source: Pastey message from Claude.
TERMS = (
    (1, 1, 221), (2, 2, 102), (3, 3, 187),
    (17, 17, 208), (34, 34, 96), (51, 51, 176),
    (109, 109, 19), (182, 182, 33), (219, 219, 50),
    (189, 189, 18), (214, 214, 35), (107, 107, 49),
    (192, 192, 7), (64, 64, 9), (128, 128, 14),
    (5, 5, 255), (10, 10, 85), (15, 15, 170),
    (80, 80, 5), (160, 160, 10), (240, 240, 15),
    (85, 85, 240), (170, 170, 80), (255, 255, 160),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    original = gf.bilinear

    def bilinear(field_bits=8):
        return TERMS if field_bits == 8 else original(field_bits)

    with patch.object(gf, "bilinear", bilinear):
        circuit = build(compact_norm=True, split_inverse=True)
    args.output.write_text(circuit)


if __name__ == "__main__":
    main()
