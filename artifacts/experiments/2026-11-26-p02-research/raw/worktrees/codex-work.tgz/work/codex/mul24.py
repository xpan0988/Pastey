"""A GF(256) multiplier via polynomial interpolation over GF(4)."""
from functools import lru_cache

import gf


def interpolate(values):
    """Recover degree-six coefficients from five evaluations and one residue."""
    # Four finite points, the leading coefficient, and a quadratic residue.
    powers = [gf.power(4, i, 4) for i in range(7)]
    rows = [[gf.power(x, i, 2) for i in range(7)] for x in range(4)]
    rows.append([0] * 6 + [1])
    rows += [[(p >> shift) & 3 for p in powers] for shift in (0, 2)]
    matrix = [row + [value] for row, value in zip(rows, values)]
    for col in range(7):
        pivot = next(i for i in range(col, 7) if matrix[i][col])
        matrix[col], matrix[pivot] = matrix[pivot], matrix[col]
        scale = gf.inv(matrix[col][col], 2)
        matrix[col] = [gf.mul(scale, a, 2) for a in matrix[col]]
        for i, row in enumerate(matrix):
            if i != col:
                scale = row[col]
                matrix[i] = [a ^ gf.mul(scale, b, 2) for a, b in zip(row, matrix[col])]
    return [row[-1] for row in matrix]


@lru_cache(maxsize=1)
def terms():
    """Return 24 triples of binary input forms and tower-basis output masks."""
    def from_poly(coeffs):
        result = 0
        for i, coefficient in enumerate(coeffs):
            result ^= gf.mul(coefficient, gf.power(16, i))
        return result

    tower_to_poly = {from_poly([(x >> (2*i)) & 3 for i in range(4)]): x for x in range(256)}
    assert len(tower_to_poly) == 256

    def evaluate(x, point, field_bits):
        result = 0
        poly = tower_to_poly[x]
        for i in reversed(range(4)):
            result = gf.mul(result, point, field_bits) ^ ((poly >> (2*i)) & 3)
        return result

    decomposition = []
    for slot, field_bits in enumerate((2, 2, 2, 2, 2, 4)):
        if slot < 4:
            input_rows = gf.lin_matrix(lambda x: evaluate(x, slot, 2))[:2]
        elif slot == 4:
            input_rows = gf.lin_matrix(lambda x: tower_to_poly[x] >> 6)[:2]
        else:
            input_rows = gf.lin_matrix(lambda x: evaluate(x, 4, 4))[:4]

        transposed = [
            sum(((row >> i) & 1) << j for j, row in enumerate(input_rows))
            for i in range(8)
        ]
        for left, right, product in gf.bilinear(field_bits):
            values = [0] * 7
            values[slot] = product & 3
            if field_bits == 4:
                values[slot + 1] = product >> 2
            decomposition.append((
                gf.apply_rows(transposed, left),
                gf.apply_rows(transposed, right),
                from_poly(interpolate(values)),
            ))
    return tuple(decomposition)
