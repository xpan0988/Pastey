"""Generate the L=3 phase oracle while retaining the input bank."""
import argparse
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "lib/qlab"), str(ROOT / "baselines")]

import gf
import spec
from e17_variants import to_kmx
from gen import Gen, bits_of
from mul24 import terms as mul24_terms


def phase_product(g, x, y, masks, x_rows, y_rows=None):
    """Apply the mask phase of (x_rows x) * y using conditional CZ."""
    for left, u, right, v, outputs in g.bilinear_terms(x, y, Lx=x_rows, Ly=y_rows):
        condition = g.parity_bit([masks[i] for i in bits_of(outputs)])
        a, undo_a = g.form(left, u)
        b, undo_b = g.form(right, v)
        g.CZ(a, b, condition)
        undo_b()
        undo_a()


def use_scaled_conjugate(g, d, ni, consume, *, split_inverse):
    """Multiply the conjugate of d by its inverse norm, then erase the product."""
    hi = d[4:]
    add = [(1 << i) | (1 << (i + 4)) for i in range(4)]
    low_terms = g.bilinear_terms(d, ni, Lx=add, m=4)
    high_terms = g.bilinear_terms(hi, ni, m=4)
    if split_inverse:
        for offset, source, rows, terms in (
            (0, d, add, low_terms),
            (4, hi, None, high_terms),
        ):
            half = g.alloc(4)
            g.mul_acc(half, source, ni, Lx=rows, m=4)
            embedding = [1 << (i - offset) if offset <= i < offset + 4 else 0 for i in range(8)]
            consume(half, embedding)
            g.erase(half, terms)
            g.free(half)
    else:
        inverse = g.alloc(8)
        g.mul_acc(inverse[:4], d, ni, Lx=add, m=4)
        g.mul_acc(inverse[4:], hi, ni, m=4)
        consume(inverse)
        terms = low_terms + [(a, u, b, v, w << 4) for a, u, b, v, w in high_terms]
        g.erase(inverse, terms)
        g.free(inverse)

def with_inverse(g, d, use_inverse, *, recycle_t6=False, split_inverse=False):
    """Use the E13 tower inverse, retaining the norm witnesses through its last use."""
    lo, hi = d[:4], d[4:]
    sq, sq4, sq8 = (
        gf.lin_matrix(lambda x: gf.power(x, exponent, 4), 4)
        for exponent in (2, 4, 8)
    )
    beta_sq = gf.lin_matrix(lambda x: gf.mul(gf.BETAS[4], gf.power(x, 2, 4), 4), 4)
    n = g.alloc(4)
    g.lin_into(n, lo, sq)
    g.lin_into(n, hi, beta_sq)
    g.mul_acc(n, lo, hi, m=4)
    t6 = g.alloc(4)
    g.mul_acc(t6, n, n, Lx=sq, Ly=sq4, m=4)
    ni = g.alloc(4)
    g.mul_acc(ni, t6, n, Ly=sq8, m=4)

    t6_terms = g.bilinear_terms(n, n, Lx=sq, Ly=sq4, m=4)
    if recycle_t6:
        g.erase(t6, t6_terms)
        g.free(t6)

    use_scaled_conjugate(g, d, ni, use_inverse, split_inverse=split_inverse)
    if recycle_t6:
        t6 = g.alloc(4)
        g.mul_acc(t6, n, n, Lx=sq, Ly=sq4, m=4)
    g.erase(ni, g.bilinear_terms(t6, n, Ly=sq8, m=4))
    g.free(ni)
    g.erase(t6, t6_terms)
    g.free(t6)
    linear = [(lo, sq[i], 1 << i) for i in range(4)]
    linear += [(hi, beta_sq[i], 1 << i) for i in range(4)]
    g.erase(n, g.bilinear_terms(lo, hi, m=4), linear)
    g.free(n)


def with_compact_inverse(g, d, consume, *, split_inverse=False):
    """Descend one more tower level and invert the GF(4) norm by squaring."""
    lo, hi = d[:4], d[4:]
    sq = gf.lin_matrix(lambda x: gf.power(x, 2, 4), 4)
    beta_sq = gf.lin_matrix(lambda x: gf.mul(gf.BETAS[4], gf.power(x, 2, 4), 4), 4)
    n = g.alloc(4)
    g.lin_into(n, lo, sq)
    g.lin_into(n, hi, beta_sq)
    g.mul_acc(n, lo, hi, m=4)

    # Compute the square of the inner norm directly, which is its inverse.
    inner_lo, inner_hi = n[:2], n[2:]
    inner_sq = gf.lin_matrix(lambda x: gf.power(x, 2, 2), 2)
    beta_squared = gf.power(gf.BETAS[2], 2, 2)
    beta_rows = gf.lin_matrix(lambda x: gf.mul(beta_squared, x, 2), 2)
    r = g.alloc(2)
    g.lin_into(r, inner_lo, [1, 2])
    g.lin_into(r, inner_hi, beta_rows)
    g.mul_acc(r, inner_lo, inner_hi, m=2, out_rows=inner_sq)

    ni = g.alloc(4)
    conjugate_low = [0b0101, 0b1010]
    g.mul_acc(ni[:2], n, r, Lx=conjugate_low, m=2)
    g.mul_acc(ni[2:], inner_hi, r, m=2)
    use_scaled_conjugate(g, d, ni, consume, split_inverse=split_inverse)

    terms = g.bilinear_terms(n, r, Lx=conjugate_low, m=2)
    terms += [(a, u, b, v, w << 2) for a, u, b, v, w in g.bilinear_terms(inner_hi, r, m=2)]
    g.erase(ni, terms)
    g.free(ni)
    terms = [
        (a, u, b, v, gf.apply_rows(inner_sq, w))
        for a, u, b, v, w in g.bilinear_terms(inner_lo, inner_hi, m=2)
    ]
    linear = [(inner_lo, 1 << i, 1 << i) for i in range(2)]
    linear += [(inner_hi, beta_rows[i], 1 << i) for i in range(2)]
    g.erase(r, terms, linear)
    g.free(r)
    linear = [(lo, sq[i], 1 << i) for i in range(4)]
    linear += [(hi, beta_sq[i], 1 << i) for i in range(4)]
    g.erase(n, g.bilinear_terms(lo, hi, m=4), linear)
    g.free(n)


def build(*, recycle_t6=False, split_inverse=False, compact_norm=False):
    if compact_norm and recycle_t6:
        raise ValueError("The compact norm has no t6 witness to recycle")
    invert = with_compact_inverse if compact_norm else with_inverse
    g = Gen()
    code = spec.code(3)
    v0, v1, v2 = [g.alloc(8) for _ in range(3)]
    masks = [g.bit() for _ in range(24)]
    for q, mask in zip(v0, masks[:8]):
        g.Z(q, mask)

    # d1 = v1 + L01(v0). Restore the original bank after node 2.
    l01, l02, l12 = code.L(0, 1), code.L(0, 2), code.L(1, 2)
    p01 = code.p(0, code.c[1])
    p02 = code.p(0, code.c[2])
    p12 = code.p(1, code.c[2])
    p01_rows = gf.lin_matrix(lambda x: gf.mul(p01, x))
    p12_rows = gf.lin_matrix(lambda x: gf.mul(p12, x))
    g.lin_into(v1, v0, l01)

    def finish_stage(inverse):
        for row, mask in zip(p01_rows, masks[8:16]):
            q, undo = g.form(inverse, row)
            g.Z(q, mask)
            undo()

        head_rows = [g.compose(row, p01_rows) for row in l12]
        g.lin_into(v2, v0, l02)
        d2 = g.alloc(8)
        g.mul_acc(d2, inverse, v2, Lx=head_rows)
        for i in bits_of(p02):
            g.X(d2[i])
        invert(
            g, d2,
            lambda reciprocal, rows=None: phase_product(
                g, v2, reciprocal, masks[16:], p12_rows, rows
            ),
            split_inverse=split_inverse,
            **({"recycle_t6": True} if recycle_t6 else {}),
        )
        for i in bits_of(p02):
            g.X(d2[i])
        g.erase(d2, g.bilinear_terms(inverse, v2, Lx=head_rows))
        g.free(d2)
        g.lin_into(v2, v0, l02)

    invert(g, v1, finish_stage)
    g.lin_into(v1, v0, l01)
    return to_kmx(g, masks, 3, "L=3 closed form with retained inversion witnesses")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--recycle-t6", action="store_true")
    parser.add_argument("--split-inverse", action="store_true")
    parser.add_argument("--compact-norm", action="store_true")
    parser.add_argument("--mul24", action="store_true")
    args = parser.parse_args()
    original_bilinear = gf.bilinear

    def bilinear(field_bits=8):
        if field_bits == 8 and args.mul24:
            return mul24_terms()
        return original_bilinear(field_bits)

    with patch.object(gf, "bilinear", bilinear):
        circuit = build(
            recycle_t6=args.recycle_t6,
            split_inverse=args.split_inverse,
            compact_norm=args.compact_norm,
        )
    args.output.write_text(circuit)



if __name__ == "__main__":
    main()
