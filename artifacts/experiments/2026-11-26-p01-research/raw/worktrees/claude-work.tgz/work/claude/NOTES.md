# claude notes
- inv2 gadget: GF(256) inversion via GF(16) inverse = conj(n)*N4(n)^2 (GF(4) norm; GF(4) inverse is linear). 9+3+3+3+18 = 36 T (incumbent 44).
  Component: `python3 check_component.py work/claude/gf256_inv2.kmx --ref baselines/components/gadget_refs.py:gf256_inv` PASS (exhaustive, 16 input bits). Regen: `python3 work/claude/inv2.py`.
- Stage: `python3 work/claude/stage2.py 3` -> L3_inv2.kmx, T=873, Q=69, full tier PASS, sha256 5ff71a2d946f7ba918e53213d0041094137c989c9441b5f08fa1d90548f1bce9.
- Saving = 10 inversions x 8 T = 80, as modelled. Untried: fusing output products, mul_acc < 27 T. Not independently reproduced yet.
- Reproduced codex retained_input (230/63, sha c9f31cee...) and live_norm (99/71, sha 698fc3b9...): byte-identical, full PASS. Generators copied read-only to work/claude/{codex_retained_input,codex_live_norm,retained_input}.py.
- codex retained_input + inv2: 198T/61Q sha 7f584f38... (superseded by live_norm 99T).
