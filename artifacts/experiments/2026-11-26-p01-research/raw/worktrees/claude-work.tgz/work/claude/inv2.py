"""Cheaper GF(256) inversion gadget: GF(16) inverse via GF(4) norm (3+3+3 ANDs instead of 18). Subclass of Gen.
   python work/claude/inv2.py  -> writes work/claude/gf256_inv2.kmx"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'lib' / 'qlab'))
import gf
from gen import Gen


class Gen2(Gen):
    def inv_into(self, t, d):
        lo, hi = d[:4], d[4:]
        sq = gf.lin_matrix(lambda x: gf.mul(x, x, 4), 4)
        bsq = gf.lin_matrix(lambda x: gf.mul(gf.BETAS[4], gf.mul(x, x, 4), 4), 4)
        n = self.alloc(4)
        self.lin_into(n, lo, sq); self.lin_into(n, hi, bsq)
        self.mul_acc(n, lo, hi, m=4)                       # n = norm(d) in GF(16)   (9)
        a, b = n[:2], n[2:]
        sq2 = gf.lin_matrix(lambda x: gf.mul(x, x, 2), 2)
        bsq2 = gf.lin_matrix(lambda x: gf.mul(gf.BETAS[2], gf.mul(x, x, 2), 2), 2)
        m = self.alloc(2)                                  # m = N4(n) in GF(4); its inverse is m^2 (linear)
        self.lin_into(m, a, sq2); self.lin_into(m, b, bsq2)
        self.mul_acc(m, a, b, m=2)                         # (3)
        ni = self.alloc(4)
        add2 = [(1 << i) | (1 << (i + 2)) for i in range(2)]
        self.mul_acc(ni[:2], n, m, Lx=add2, Ly=sq2, m=2)   # (a+b) * m^2   (3)
        self.mul_acc(ni[2:], b, m, Ly=sq2, m=2)            # b * m^2       (3)
        add = [(1 << i) | (1 << (i + 4)) for i in range(4)]
        self.mul_acc(t[:4], d, ni, Lx=add, m=4)            # 9
        self.mul_acc(t[4:], hi, ni, m=4)                   # 9
        self.erase(ni[2:], terms=self.bilinear_terms(b, m, Ly=sq2, m=2))
        self.erase(ni[:2], terms=self.bilinear_terms(n, m, Lx=add2, Ly=sq2, m=2))
        self.free(ni)
        lin = [(a, sq2[i], 1 << i) for i in range(2)] + [(b, bsq2[i], 1 << i) for i in range(2)]
        self.erase(m, terms=self.bilinear_terms(a, b, m=2), linear=lin); self.free(m)
        lin = [(lo, sq[i], 1 << i) for i in range(4)] + [(hi, bsq[i], 1 << i) for i in range(4)]
        self.erase(n, terms=self.bilinear_terms(lo, hi, m=4), linear=lin); self.free(n)


if __name__ == '__main__':
    g = Gen2(); d, t = g.alloc(8), g.alloc(8); g.inv_into(t, d)
    reg = lambda nm, qs, k: f'#{k} {nm} ' + ' '.join(f'q{q}' for q in qs)
    out = Path(__file__).with_name('gf256_inv2.kmx')
    out.write_text('\n'.join([f'# work/claude/inv2.py: out ^= inv(d), {g.tof} Toffolis', reg('d', d, 'in'),
                              reg('out', t, 'out')] + g.lines) + '\n')
    print('Toffolis', g.tof)
