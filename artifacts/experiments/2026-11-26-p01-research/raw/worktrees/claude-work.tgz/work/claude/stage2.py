"""Incumbent forwarded_old_value schedule with Gen2.inv_into (36 T inversion).
   python3 work/claude/stage2.py [L]  -> work/claude/L{L}_inv2.kmx"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'baselines'), str(Path(__file__).parent)]
import e17_variants as e
from inv2 import Gen2
e.Gen = Gen2
L = int(sys.argv[1]) if len(sys.argv) > 1 else 3
g, masks, info = e.build('forwarded_old_value', L)
p = Path(__file__).parent / f'L{L}_inv2.kmx'
p.write_text(e.to_kmx(g, masks, L, f'incumbent schedule + inv2 gadget, L={L}; work/claude/stage2.py'))
print(info['toffolis'], info['peak_live_qubits'], info['physical_qubits'], p)
