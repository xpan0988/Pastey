# work/

Your space. Nothing here is read by the verifier. Suggested only so that results are findable later:
one subdirectory per line of inquiry, each with the generator that emits its circuit(s) and a short NOTES.md
(claim, evidence level, circuit SHA-256, regeneration command). Organise it however you like.
