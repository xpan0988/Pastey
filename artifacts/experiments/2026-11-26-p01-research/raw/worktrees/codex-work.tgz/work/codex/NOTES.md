# Retained-input L=3 stage

```sh
python3 work/codex/retained_input.py work/codex/retained_input.kmx
python3 verify.py work/codex/retained_input.kmx --tier full --json work/codex/retained_input.json
```

SHA-256 `c9f31ceed8b683ac6c977dddff2a52617b91ca31c2cb4ed4595a150301c39008`.
Full-tier PASS on 16,646,400 valid inputs, symbolically covering all masks and measurement outcomes. The circuit uses 230 Toffolis, 63 qubits and 202 HMRs. The incumbent uses 953 Toffolis and 71 qubits.

Let (a_k = v_k + L_{0k}(v_0)). The first head is (p_0(c_1)/a_1). The second head is (p_1(c_2)a_2/(p_0(c_2)+L_{12}(h_1)a_2)). The generator evaluates these using temporary linear changes of coordinates on the input bank, which it reverses after cleanup. It erases the second quotient and the nonconstant part of its denominator using the bilinear phase corrections in `Gen.erase`. It clears both reciprocal registers by applying `Gen.inv_into` again. This costs four inversions and two multiplications.

## Live tower norms and direct phase

```sh
python3 work/codex/live_norm.py work/codex/live_norm.kmx
python3 verify.py work/codex/live_norm.kmx --tier full --json work/codex/live_norm.json
```

SHA-256 `698fc3b92be406a66f5c2efcce687d0a7964fd36b9e37d8eabae49deb9e54b80`.
Full-tier PASS at 99 Toffolis, 71 qubits and 99 HMRs.

The reciprocal construction retains tower norms so every nonlinear temporary can be erased by measurement and Clifford correction. Each GF(256) inverse costs 36 Toffolis: 9 for the outer norm, 9 for the GF(16) inverse, and 18 for the conjugate scaling. Each term of the second quotient is a product of two linear forms controlled in phase by a classical parity of mask bits. The circuit emits those terms as conditional CZs. Its only remaining GF(256) product computes the denominator.

## Compact live norms

```sh
python3 work/codex/live_norm.py --compact --in-place work/codex/live_norm_compact.kmx
python3 verify.py work/codex/live_norm_compact.kmx --tier full --json work/codex/live_norm_compact.json
```

SHA-256 `f222cb3b657da128d50faac397d1ac70c42f8f2f5464a08fdab9dd8633c6594e`.
Full-tier PASS at 99 Toffolis and 65 qubits. Streaming the two halves of the second reciprocal saves four qubits. Temporary in-place linear forms save two more. The simultaneous controls in this generator use disjoint registers, and each pivot is restored after use. The default command still regenerates the original 99/71 circuit byte for byte.
