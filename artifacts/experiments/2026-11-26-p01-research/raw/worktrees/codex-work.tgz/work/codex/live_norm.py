"""Generate the L=3 stage with live inversion norms and direct bilinear phase."""
import argparse
from contextlib import contextmanager
from pathlib import Path

from retained_input import Gen, gf, spec, to_kmx
from qlab.gen import bits_of


class InPlaceForms(Gen):
    """Linear forms may use a pivot when simultaneous operands are disjoint."""

    def form(self, reg, mask):
        indices = bits_of(mask)
        pivot = reg[indices[0]]
        sources = [reg[i] for i in indices[1:]]

        def toggle():
            for source in sources:
                self.CX(source, pivot)

        toggle()
        return pivot, toggle


@contextmanager
def reciprocal(g, value, *, stream=False):
    """Keep the tower norms live until the reciprocal has been used."""
    width = len(value)
    half = width // 2
    if width == 2:
        square = gf.lin_matrix(lambda x: gf.mul(x, x, width), width)
        yield value, square
        return

    result = None if stream else g.alloc(width)
    lo, hi = value[:half], value[half:]
    square = gf.lin_matrix(lambda x: gf.mul(x, x, half), half)
    beta_square = gf.lin_matrix(
        lambda x: gf.mul(gf.BETAS[half], gf.mul(x, x, half), half), half
    )
    norm = g.alloc(half)
    g.lin_into(norm, lo, square)
    g.lin_into(norm, hi, beta_square)
    g.mul_acc(norm, lo, hi, m=half)
    conjugate_lo = [(1 << i) | (1 << (i + half)) for i in range(half)]
    with reciprocal(g, norm) as (inv_norm, rows):
        halves = ((value, conjugate_lo), (hi, None))

        @contextmanager
        def scale_half(index):
            source, source_rows = halves[index]
            output = g.alloc(half)
            g.mul_acc(output, source, inv_norm, Lx=source_rows, Ly=rows, m=half)
            yield output
            g.erase(output, terms=g.bilinear_terms(
                source, inv_norm, Lx=source_rows, Ly=rows, m=half
            ))
            g.free(output)

        if stream:
            yield scale_half
        else:
            # Allocate the full result before computing either half.
            for output, (source, source_rows) in zip(
                (result[:half], result[half:]), halves
            ):
                g.mul_acc(output, source, inv_norm, Lx=source_rows, Ly=rows, m=half)
            yield result, None
            for output, (source, source_rows) in zip(
                (result[:half], result[half:]), halves
            ):
                g.erase(output, terms=g.bilinear_terms(
                    source, inv_norm, Lx=source_rows, Ly=rows, m=half
                ))
    linear = [
        (reg, row, 1 << i)
        for reg, rows in ((lo, square), (hi, beta_square))
        for i, row in enumerate(rows)
    ]
    g.erase(norm, terms=g.bilinear_terms(lo, hi, m=half), linear=linear)
    g.free(norm)
    if result is not None:
        g.free(result)


def product_phase(g, x, y, masks, *, x_rows, y_rows=None):
    for left, u, right, v, w in g.bilinear_terms(x, y, Lx=x_rows, Ly=y_rows):
        control = g.parity_bit([masks[i] for i in bits_of(w)])
        a, undo_a = g.form(left, u)
        b, undo_b = g.form(right, v)
        g.CZ(a, b, control)
        undo_b()
        undo_a()


def build(*, compact=False, in_place=False):
    g = InPlaceForms() if in_place else Gen()
    v0, v1, v2 = (g.alloc(8) for _ in range(3))
    masks = [g.bit() for _ in range(24)]
    code = spec.code(3)
    p01 = code.p(0, code.c[1])
    p02 = code.p(0, code.c[2])
    p12 = code.p(1, code.c[2])
    l01, l02, l12 = code.L(0, 1), code.L(0, 2), code.L(1, 2)
    head1_rows = gf.lin_matrix(lambda x: gf.mul(x, p01))
    eval1_rows = gf.lin_matrix(lambda x: gf.apply_rows(l12, gf.mul(x, p01)))
    numerator_rows = gf.lin_matrix(lambda x: gf.mul(x, p12))

    g.lin_into(v1, v0, l01)
    g.lin_into(v2, v0, l02)
    for q, mask in zip(v0, masks[:8]):
        g.Z(q, mask)
    with reciprocal(g, v1) as (inv1, _):
        for row, mask in zip(head1_rows, masks[8:16]):
            q, undo = g.form(inv1, row)
            g.Z(q, mask)
            undo()
        denominator = g.alloc(8)
        g.mul_acc(denominator, inv1, v2, Lx=eval1_rows)
        for i in bits_of(p02):
            g.X(denominator[i])
        if compact:
            with reciprocal(g, denominator, stream=True) as scale_half:
                for half in range(2):
                    projection = [
                        1 << (i % 4) if i // 4 == half else 0 for i in range(8)
                    ]
                    with scale_half(half) as inv_half:
                        product_phase(
                            g, v2, inv_half, masks[16:],
                            x_rows=numerator_rows, y_rows=projection
                        )
        else:
            with reciprocal(g, denominator) as (inv2, _):
                product_phase(g, v2, inv2, masks[16:], x_rows=numerator_rows)
        for i in bits_of(p02):
            g.X(denominator[i])
        g.erase(denominator, terms=g.bilinear_terms(inv1, v2, Lx=eval1_rows))
        g.free(denominator)
    g.lin_into(v2, v0, l02)
    g.lin_into(v1, v0, l01)
    assert g.live == 24
    return to_kmx(g, masks, 3, "L=3 stage with live tower norms and direct phase")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--compact", action="store_true")
    parser.add_argument("--in-place", action="store_true")
    args = parser.parse_args()
    circuit = build(compact=args.compact, in_place=args.in_place)
    args.output.write_bytes(circuit.encode("ascii"))
