"""Generate the retained-input L=3 phase oracle."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "lib"))

from baselines.e17_variants import to_kmx
from qlab import gf, spec
from qlab.gen import Gen


def build():
    g = Gen()
    v0, v1, v2 = (g.alloc(8) for _ in range(3))
    masks = [g.bit() for _ in range(24)]
    code = spec.code(3)
    p01 = code.p(0, code.c[1])
    p02 = code.p(0, code.c[2])
    p12 = code.p(1, code.c[2])
    l01, l02, l12 = code.L(0, 1), code.L(0, 2), code.L(1, 2)
    scale1 = gf.lin_matrix(lambda x: gf.mul(x, p01))
    unscale1 = gf.lin_matrix(lambda x: gf.mul(x, gf.inv(p01)))
    scale2 = gf.lin_matrix(lambda x: gf.mul(x, p12))

    # The bank retains its input information in temporary linear coordinates.
    g.lin_into(v1, v0, l01)
    g.lin_into(v2, v0, l02)
    h1 = g.alloc(8)
    g.inv_into(h1, v1)
    g.const_mul_inplace(h1, scale1)
    for reg, offset in ((v0, 0), (h1, 8)):
        for i, q in enumerate(reg):
            g.Z(q, masks[offset + i])

    # After two projective steps the numerator is p12*v2 and the
    # denominator is p02 + L12(h1)*v2, in the linear coordinates above.
    denominator = g.alloc(8)
    g.mul_acc(denominator, h1, v2, Lx=l12)
    for i, q in enumerate(denominator):
        if p02 >> i & 1:
            g.X(q)
    reciprocal = g.alloc(8)
    g.inv_into(reciprocal, denominator)
    h2 = g.alloc(8)
    g.mul_acc(h2, v2, reciprocal, Lx=scale2)
    for i, q in enumerate(h2):
        g.Z(q, masks[16 + i])
    g.erase(h2, terms=g.bilinear_terms(v2, reciprocal, Lx=scale2))
    g.free(h2)

    g.inv_into(reciprocal, denominator)
    g.free(reciprocal)
    for i, q in enumerate(denominator):
        if p02 >> i & 1:
            g.X(q)
    g.erase(denominator, terms=g.bilinear_terms(h1, v2, Lx=l12))
    g.free(denominator)
    g.const_mul_inplace(h1, unscale1)
    g.inv_into(h1, v1)
    g.free(h1)
    g.lin_into(v2, v0, l02)
    g.lin_into(v1, v0, l01)
    assert g.live == 24
    return to_kmx(g, masks, 3, "Retained-input L=3 stage")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.write_bytes(build().encode("ascii"))
